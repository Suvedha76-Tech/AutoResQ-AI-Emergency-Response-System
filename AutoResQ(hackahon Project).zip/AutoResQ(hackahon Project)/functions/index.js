const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();


// 🚨 1. When accident alert is created → send notification to ALL users
exports.onAlertCreated = functions.firestore
.document("alerts/{id}")
.onCreate(async (snap, context) => {

    const alert = snap.data();

    const users = await admin.firestore().collection("users").get();

    let tasks = [];

    users.forEach(doc => {

        const user = doc.data();

        const payload = {
            notification: {
                title: "🚨 Emergency Alert",
                body: `${alert.victimName} needs help nearby`
            },
            data: {
                type: "NEW_ALERT",
                lat: alert.lat.toString(),
                lng: alert.lng.toString(),
                alertId: context.params.id
            },
            token: user.fcmToken
        };

        tasks.push(admin.messaging().send(payload));
    });

    return Promise.all(tasks);
});


// 🚑 2. When helper reaches victim → notify ALL users
exports.onHelperReached = functions.firestore
.document("alerts/{id}")
.onUpdate(async (change, context) => {

    const before = change.before.data();
    const after = change.after.data();

    // Only trigger when helperReached becomes true
    if (before.helperReached === false && after.helperReached === true) {

        const users = await admin.firestore().collection("users").get();

        let tasks = [];

        users.forEach(doc => {

            const user = doc.data();

            const payload = {
                notification: {
                    title: "🚑 Help Arrived",
                    body: `${after.victimName} got help`
                },
                data: {
                    type: "HELPER_REACHED"
                },
                token: user.fcmToken
            };

            tasks.push(admin.messaging().send(payload));
        });

        return Promise.all(tasks);
    }

    return null;
});
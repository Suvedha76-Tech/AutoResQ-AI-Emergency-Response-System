package com.roadsos.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_prefs")

class UserPreferences(private val context: Context) {

    companion object {

        val REGISTERED_KEY = booleanPreferencesKey("registered")
        val PHONE_KEY = stringPreferencesKey("phone")
        val CONTACT1_KEY = stringPreferencesKey("contact1")
        val CONTACT2_KEY = stringPreferencesKey("contact2")
    }

    suspend fun setUserRegistered(value: Boolean) {

        context.dataStore.edit {

            it[REGISTERED_KEY] = value
        }
    }

    val isUserRegistered: Flow<Boolean> =

        context.dataStore.data.map {

            it[REGISTERED_KEY] ?: false
        }

    // 🔥 SAVE PHONE
    suspend fun savePhone(phone: String) {

        context.dataStore.edit {

            it[PHONE_KEY] = phone
        }
    }

    // 🔥 GET PHONE
    val userPhone: Flow<String> =

        context.dataStore.data.map {

            it[PHONE_KEY] ?: ""
        }

    // 🔥 SAVE EMERGENCY CONTACTS
    suspend fun saveEmergencyContacts(c1: String, c2: String) {

        context.dataStore.edit {

            it[CONTACT1_KEY] = c1

            it[CONTACT2_KEY] = c2
        }
    }

    // 🔥 GET EMERGENCY CONTACTS
    val contact1: Flow<String> =
        context.dataStore.data.map { it[CONTACT1_KEY] ?: "" }

    val contact2: Flow<String> =
        context.dataStore.data.map { it[CONTACT2_KEY] ?: "" }

    val emergencyContacts: Flow<Pair<String, String>> =
        context.dataStore.data.map {
            Pair(it[CONTACT1_KEY] ?: "", it[CONTACT2_KEY] ?: "")
        }
}
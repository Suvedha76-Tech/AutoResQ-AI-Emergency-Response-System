package com.roadsos.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import com.roadsos.app.data.local.UserPreferences
import kotlinx.coroutines.flow.first
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.roadsos.app.viewmodel.MainViewModel

@Composable
fun ProfileScreen(
    navController: NavController,
    viewModel: MainViewModel
) {

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var vehicle by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("") }
    var contact1 by remember { mutableStateOf("") }
    var contact2 by remember { mutableStateOf("") }

    var editMode by remember { mutableStateOf(false) }

    // 🔥 FIREBASE LOAD
    val context = LocalContext.current

    val userPrefs = UserPreferences(context)

    LaunchedEffect(Unit) {

        val savedPhone = userPrefs.userPhone.first()

        viewModel.getUser(savedPhone) { data ->

            data?.let {

                name = it["name"].toString()
                phone = it["phone"].toString()
                vehicle = it["vehicle"].toString()
                bloodGroup = it["bloodGroup"].toString()
                contact1 = it["contact1"].toString()
                contact2 = it["contact2"].toString()
            }
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {

        Text(
            text = "My Profile",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = name,
            onValueChange = {
                if (editMode) name = it
            },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth(),
            enabled = editMode
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = {},
            label = { Text("Phone") },
            modifier = Modifier.fillMaxWidth(),
            enabled = false
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = vehicle,
            onValueChange = {
                if (editMode) vehicle = it.uppercase()
            },
            label = { Text("Vehicle Number") },
            modifier = Modifier.fillMaxWidth(),
            enabled = editMode
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = bloodGroup,
            onValueChange = {
                if (editMode) bloodGroup = it.uppercase()
            },
            label = { Text("Blood Group") },
            modifier = Modifier.fillMaxWidth(),
            enabled = editMode
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = contact1,
            onValueChange = {
                if (editMode) contact1 = it
            },
            label = { Text("Emergency Contact 1") },
            modifier = Modifier.fillMaxWidth(),
            enabled = editMode
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = contact2,
            onValueChange = {
                if (editMode) contact2 = it
            },
            label = { Text("Emergency Contact 2") },
            modifier = Modifier.fillMaxWidth(),
            enabled = editMode
        )

        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = {

                if (editMode) {

                    val data = mapOf(
                        "name" to name,
                        "phone" to phone,
                        "vehicle" to vehicle,
                        "bloodGroup" to bloodGroup,
                        "contact1" to contact1,
                        "contact2" to contact2
                    )

                    if (phone.isNotBlank()) {

                        viewModel.updateUser(phone, data)

                        editMode = false
                    }

                } else {

                    editMode = true
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                if (editMode) "Save Changes"
                else "Edit Profile"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                navController.popBackStack()
            },
            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Back")
        }
    }
}
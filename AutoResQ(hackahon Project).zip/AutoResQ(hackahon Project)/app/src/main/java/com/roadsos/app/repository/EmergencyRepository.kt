package com.roadsos.app.repository

import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.roadsos.app.data.model.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlin.math.*

class EmergencyRepository {

    private val db = FirebaseFirestore.getInstance()
    private val activeEmergenciesRef = db.collection("active_emergencies")
    private val usersRef = db.collection("users")

    companion object {
        private const val TAG = "EmergencyRepository"
    }

    // ─── CREATE EMERGENCY (SOS Triggered) ───────────────────────────────────
    suspend fun createEmergency(userId: String, latitude: Double, longitude: Double, userName: String): Result<String> {
        val emergency = Emergency(
            userId = userId,
            username = userName,
            latitude = latitude,
            longitude = longitude,
            status = "AWAITING_RESPONDERS",
            timestamp = com.google.firebase.Timestamp.now(),
            active = true
        )
        return createEmergency(emergency)
    }

    suspend fun createEmergency(emergency: Emergency): Result<String> {
        return try {
            val docRef = activeEmergenciesRef.add(emergency.toMap()).await()
            Log.d(TAG, "Emergency created in active_emergencies: ${docRef.id}")
            Result.success(docRef.id)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create emergency", e)
            Result.failure(e)
        }
    }

    // ─── REAL-TIME LISTENER: Active Emergencies ─────────────────────────────
    fun listenToActiveEmergencies(): Flow<List<Emergency>> = callbackFlow {
        val listener: ListenerRegistration = activeEmergenciesRef
            .whereEqualTo("active", true)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Firestore listen error", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.data?.toEmergency(doc.id)
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // ─── REAL-TIME LISTENER: Single Emergency ────────────────────────────────
    fun listenToEmergency(emergencyId: String): Flow<Emergency?> = callbackFlow {
        val listener = activeEmergenciesRef.document(emergencyId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                val data = snapshot?.data
                trySend(data?.toEmergency(snapshot.id))
            }
        awaitClose { listener.remove() }
    }

    // ─── UPDATE EMERGENCY STATUS ─────────────────────────────────────────────
    suspend fun updateEmergencyStatus(emergencyId: String, status: String) {
        try {
            val updates = mutableMapOf<String, Any>(
                "status" to status,
                "lastUpdated" to com.google.firebase.Timestamp.now()
            )
            if (status == "RESOLVED") {
                updates["active"] = false
            }
            activeEmergenciesRef.document(emergencyId).update(updates).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update status", e)
        }
    }

    // ─── ACCEPT HELP FLOW ──────────────────────────────────────────────────
    suspend fun acceptHelp(emergencyId: String, responderId: String, responderName: String, lat: Double, lng: Double) {
        try {
            val update = mapOf(
                "status" to "RESPONDER_ASSIGNED",
                "responderId" to responderId,
                "responderName" to responderName,
                "responderLat" to lat,
                "responderLng" to lng,
                "respondersCount" to FieldValue.increment(1),
                "responderETA" to "3 min", // Mock ETA for now
                "lastUpdated" to com.google.firebase.Timestamp.now()
            )
            activeEmergenciesRef.document(emergencyId).update(update).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to accept help", e)
        }
    }

    // ─── UPDATE RESPONDER POSITION ──────────────────────────────────────────
    suspend fun updateResponderPosition(emergencyId: String, lat: Double, lng: Double, eta: String) {
        try {
            activeEmergenciesRef.document(emergencyId).update(
                mapOf(
                    "responderLat" to lat,
                    "responderLng" to lng,
                    "responderETA" to eta,
                    "lastUpdated" to com.google.firebase.Timestamp.now()
                )
            ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update responder position", e)
        }
    }

    // ─── USER LOCATION UPDATES ───────────────────────────────────────────────
    suspend fun updateUserLocation(userId: String, lat: Double, lng: Double) {
        try {
            usersRef.document(userId).update(
                mapOf("latitude" to lat, "longitude" to lng, "lastUpdated" to com.google.firebase.Timestamp.now())
            ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update user location", e)
        }
    }

    suspend fun getUserData(phone: String): Map<String, Any>? {
        return try {
            val doc = usersRef.document(phone).get().await()
            doc.data
        } catch (e: Exception) {
            null
        }
    }

    suspend fun saveUserProfile(userId: String, data: Map<String, Any>) {
        try {
            usersRef.document(userId).set(data, com.google.firebase.firestore.SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save profile", e)
        }
    }

    // ─── DISTANCE CALCULATION ───────────────────────────────────────────────
    fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2)
        return R * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    fun formatDistance(km: Double): String {
        return if (km < 1.0) "${(km * 1000).toInt()} m" else String.format("%.1f km", km)
    }

    // ─── LISTEN TO HELPERS ──────────────────────────────────────────────────
    fun listenToHelpers(emergencyId: String): Flow<List<Helper>> = callbackFlow {
        val listener = activeEmergenciesRef.document(emergencyId).collection("helpers")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    Helper(
                        userId = doc.id,
                        name = data["name"] as? String ?: "Unknown",
                        latitude = data["latitude"] as? Double ?: 0.0,
                        longitude = data["longitude"] as? Double ?: 0.0,
                        status = try { 
                            HelperStatus.valueOf(data["status"] as? String ?: "ALERTED") 
                        } catch (e: Exception) { 
                            HelperStatus.ALERTED 
                        }
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // ─── ESCALATE EMERGENCY ────────────────────────────────────────────────
    suspend fun escalateEmergency(emergencyId: String, radius: Double, priority: String) {
        try {
            activeEmergenciesRef.document(emergencyId).update(
                mapOf(
                    "radius" to radius,
                    "priority" to priority,
                    "status" to "ESCALATED",
                    "lastUpdated" to com.google.firebase.Timestamp.now()
                )
            ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to escalate", e)
        }
    }

    // ─── ADD EVIDENCE URL ──────────────────────────────────────────────────
    suspend fun addEvidenceUrl(emergencyId: String, url: String, type: String) {
        try {
            activeEmergenciesRef.document(emergencyId).collection("evidence").add(
                mapOf(
                    "url" to url,
                    "type" to type,
                    "timestamp" to com.google.firebase.Timestamp.now()
                )
            ).await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add evidence", e)
        }
    }

    suspend fun getAllUsers(): List<User> {
        return try {
            val snapshot = usersRef.get().await()
            snapshot.documents.mapNotNull { doc ->
                val data = doc.data ?: return@mapNotNull null
                User(
                    id = doc.id,
                    name = data["name"] as? String ?: "Unknown",
                    phone = data["phone"] as? String ?: "",
                    latitude = data["latitude"] as? Double ?: 0.0,
                    longitude = data["longitude"] as? Double ?: 0.0
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

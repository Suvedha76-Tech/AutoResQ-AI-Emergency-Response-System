package com.roadsos.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.roadsos.app.data.local.UserPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class OrbState {
    IDLE, LISTENING, THINKING, RESPONDING, EMERGENCY
}

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val actions: List<AIAction> = emptyList()
)

data class AIAction(
    val label: String,
    val type: ActionType
)

enum class ActionType {
    SOS, NAVIGATE, CALL, SUGGEST_ROUTE, OPEN_MAP, CANCEL, VIEW_ROUTE_RISK
}

data class RouteRiskState(
    val safetyScore: Int = 82,
    val trafficSeverity: String = "MODERATE",
    val riskZones: Int = 2,
    val weatherRisk: String = "LOW",
    val nightRisk: String = "MEDIUM",
    val isAnalyzing: Boolean = false
)

data class AIAssistantState(
    val orbState: OrbState = OrbState.IDLE,
    val chatHistory: List<ChatMessage> = emptyList(),
    val isTyping: Boolean = false,
    val rmsdB: Float = 0f,
    val routeRisk: RouteRiskState = RouteRiskState()
)

class AIAssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val userPrefs = UserPreferences(application)
    private val _uiState = MutableStateFlow(AIAssistantState())
    val uiState = _uiState.asStateFlow()

    init {
        generateGreeting()
    }

    private fun generateGreeting() {
        viewModelScope.launch {
            // Note: Since userName is not in UserPreferences, we'll use a generic greeting or check if we can get it from Firestore later if needed.
            // For now, let's keep it friendly.
            _uiState.update { it.copy(isTyping = true, orbState = OrbState.THINKING) }
            delay(1200)
            val greeting = "Hi there! 👋\nI'm ResQ AI.\nHow can I assist you today?"
            _uiState.update { state ->
                state.copy(
                    chatHistory = listOf(ChatMessage(greeting, false)),
                    isTyping = false,
                    orbState = OrbState.RESPONDING
                )
            }
            delay(2000)
            _uiState.update { it.copy(orbState = OrbState.IDLE) }
        }
    }

    fun onUserMessage(text: String) {
        if (text.isBlank()) return
        
        _uiState.update { state ->
            state.copy(
                chatHistory = state.chatHistory + ChatMessage(text, true),
                orbState = OrbState.THINKING,
                isTyping = true
            )
        }

        viewModelScope.launch {
            delay(1500)
            val (response, actions) = getSmartResponse(text)
            
            _uiState.update { state ->
                state.copy(
                    chatHistory = state.chatHistory + ChatMessage(response, false, actions = actions),
                    isTyping = false,
                    orbState = OrbState.RESPONDING
                )
            }
            
            delay(4000)
            if (_uiState.value.orbState == OrbState.RESPONDING) {
                _uiState.update { it.copy(orbState = OrbState.IDLE) }
            }
        }
    }

    private fun getSmartResponse(input: String): Pair<String, List<AIAction>> {
        val query = input.lowercase()
        return when {
            query.contains("safe") || query.contains("road") || query.contains("risk") || query.contains("check route") || query.contains("analyze") || query.contains("danger") -> {
                "I've analyzed your current path. The route has a moderate accident probability due to traffic and visibility. I recommend viewing the full AI risk analysis." to listOf(
                    AIAction("Analyze Route Risk", ActionType.VIEW_ROUTE_RISK),
                    AIAction("Suggest Safe Route", ActionType.SUGGEST_ROUTE)
                )
            }
            query.contains("fatigue") || query.contains("tired") || query.contains("sleepy") -> {
                "Fatigue risk detection active. I recommend taking a break at the nearest safe zone. Would you like me to find a safe parking area?" to listOf(
                    AIAction("Find Safe Parking", ActionType.NAVIGATE),
                    AIAction("Ignore", ActionType.CANCEL)
                )
            }
            query.contains("isolated") || query.contains("dark") || query.contains("lonely") -> {
                "Detecting isolated road section. Women Safety Mode activated. Monitoring your live location strictly and notifying emergency contacts." to listOf(
                    AIAction("View Status", ActionType.VIEW_ROUTE_RISK),
                    AIAction("Emergency SOS", ActionType.SOS)
                )
            }
            query.contains("ambulance") || query.contains("doctor") -> {
                "Requesting emergency medical assistance... Searching for nearest ambulance service." to listOf(
                    AIAction("Request Ambulance", ActionType.CALL),
                    AIAction("Call Hospital", ActionType.CALL)
                )
            }
            query.contains("hospital") -> {
                "Nearest hospital found: City Care Hospital, 1.1 km away. Estimated arrival time: 4 minutes." to listOf(
                    AIAction("Navigate", ActionType.NAVIGATE),
                    AIAction("Call", ActionType.CALL)
                )
            }
            query.contains("help") || query.contains("emergency") || query.contains("sos") -> {
                _uiState.update { it.copy(orbState = OrbState.EMERGENCY) }
                "I’m here with you.\nDo you want me to activate emergency SOS protection?" to listOf(
                    AIAction("YES SOS", ActionType.SOS),
                    AIAction("Cancel", ActionType.CANCEL)
                )
            }
            else -> "I understand. I am continuously monitoring your route and safety status. Feel free to ask about nearby risks or hospitals." to emptyList()
        }
    }

    fun analyzeRouteRisk() {
        viewModelScope.launch {
            _uiState.update { it.copy(routeRisk = it.routeRisk.copy(isAnalyzing = true), orbState = OrbState.THINKING) }
            delay(2500)
            _uiState.update { it.copy(
                routeRisk = RouteRiskState(
                    safetyScore = (75..95).random(),
                    trafficSeverity = listOf("LOW", "MODERATE", "HEAVY").random(),
                    riskZones = (0..3).random(),
                    isAnalyzing = false
                ),
                orbState = OrbState.RESPONDING
            ) }
            delay(2000)
            _uiState.update { it.copy(orbState = OrbState.IDLE) }
        }
    }

    fun setOrbState(state: OrbState) {
        _uiState.update { it.copy(orbState = state) }
    }
    
    fun updateRms(rms: Float) {
        _uiState.update { it.copy(rmsdB = rms) }
    }
}

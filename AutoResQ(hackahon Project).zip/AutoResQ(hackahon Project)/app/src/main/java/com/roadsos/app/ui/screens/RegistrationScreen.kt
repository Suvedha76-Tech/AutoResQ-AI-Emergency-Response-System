package com.roadsos.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.roadsos.app.data.local.UserPreferences
import com.roadsos.app.viewmodel.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun RegistrationScreen(viewModel: MainViewModel, navController: NavController) {

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var contact1 by remember { mutableStateOf("") }
    var contact2 by remember { mutableStateOf("") }
    var vehicle by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("") }

    val context = LocalContext.current
    val userPrefs = UserPreferences(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()) // 🔥 IMPORTANT FIX
    ) {

        Text(
            "Welcome To AutoResQ !",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Phone") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = age,
            onValueChange = { age = it },
            label = { Text("Age") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = contact1,
            onValueChange = {
                contact1 = it.filter { ch -> ch.isDigit() }
            },
            label = { Text("Emergency Contact 1") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = contact2,
            onValueChange = {
                contact2 = it.filter { ch -> ch.isDigit() }
            },
            label = { Text("Emergency Contact 2") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = vehicle,
            onValueChange = { vehicle = it.uppercase() }, // 🔥 FIX
            label = { Text("Vehicle Number") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = bloodGroup,
            onValueChange = { bloodGroup = it.uppercase() }, // 🔥 FIX
            label = { Text("Blood Group (A+, O-, etc)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                val ageInt = age.toIntOrNull()

                // 🔥 SAFE VALIDATION
                if (name.isBlank() || phone.isBlank() || age.isBlank()) return@Button
                if (ageInt == null || ageInt < 15) return@Button

                val validBloodGroups = listOf(
                    "A+", "A-", "B+", "B-",
                    "AB+", "AB-", "O+", "O-"
                )

                if (bloodGroup.isNotBlank() && bloodGroup.uppercase() !in validBloodGroups) {
                    return@Button
                }

                viewModel.saveUserToFirebase(
                    name,
                    phone,
                    ageInt,
                    contact1,
                    contact2,
                    vehicle,
                    bloodGroup
                )

                CoroutineScope(Dispatchers.IO).launch {

                    userPrefs.setUserRegistered(true)

                    userPrefs.savePhone(phone)

                    userPrefs.saveEmergencyContacts(
                        contact1,
                        contact2
                    )
                }

                navController.navigate("home") {
                    popUpTo("register") { inclusive = true } // 🔥 BACK FIX
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Register")
        }
    }
}
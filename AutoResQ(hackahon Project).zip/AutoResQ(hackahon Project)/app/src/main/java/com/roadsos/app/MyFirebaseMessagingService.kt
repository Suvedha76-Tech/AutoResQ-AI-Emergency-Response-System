package com.roadsos.app

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
        val senderUid = remoteMessage.data["senderUid"]
        
        // CRITICAL SELF-FILTER RULE: return immediately if it's our own SOS
        if (senderUid != null && senderUid == currentUser?.uid) {
            return
        }

        val title = remoteMessage.notification?.title ?: remoteMessage.data["title"] ?: "URGENT ALERT"
        val body = remoteMessage.notification?.body ?: remoteMessage.data["body"] ?: "Emergency reported nearby"
        val screen = remoteMessage.data["screen"]

        showNotification(title, body, screen)
    }

    private fun showNotification(title: String, message: String, screen: String?) {
        val intent = Intent(this, MainActivity::class.java).apply {
            if (screen == "RESCUE_NEXUS") {
                putExtra("navigate_to", "map")
            }
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, "alert_channel")
            .setSmallIcon(R.drawable.ic_warning)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        val manager = getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager

        manager.notify(1, builder.build())
    }
}
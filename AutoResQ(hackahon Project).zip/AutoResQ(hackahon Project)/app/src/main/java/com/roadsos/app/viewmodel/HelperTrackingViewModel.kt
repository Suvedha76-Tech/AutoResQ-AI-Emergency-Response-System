package com.roadsos.app.viewmodel

import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class HelperTrackingViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    // ✅ When user clicks "I CAN HELP"
    fun acceptHelp(alertId: String, helperId: String) {

        val data = mapOf(
            "helperId" to helperId,
            "status" to "accepted"
        )

        db.collection("alerts")
            .document(alertId)
            .update(data)
    }

    // 🚑 When helper reaches victim location
    fun markHelperReached(alertId: String, helperId: String) {

        val data = mapOf(
            "helperId" to helperId,
            "helperReached" to true,
            "status" to "completed",
            "reachedTime" to FieldValue.serverTimestamp()
        )

        db.collection("alerts")
            .document(alertId)
            .update(data)
    }

    // ❌ If helper cancels
    fun cancelHelp(alertId: String, helperId: String) {

        val data = mapOf(
            "helperId" to "",
            "status" to "cancelled"
        )

        db.collection("alerts")
            .document(alertId)
            .update(data)
    }
}
package com.roadsos.app.service

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast

class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val phoneNumber = intent.getStringExtra("phone") ?: "Unknown"
        when (resultCode) {
            Activity.RESULT_OK -> {
                Log.d("SMS_STATUS", "SMS Sent Successfully to $phoneNumber")
                Toast.makeText(context, "SOS SMS Sent Successfully to $phoneNumber", Toast.LENGTH_SHORT).show()
            }
            SmsManager.RESULT_ERROR_GENERIC_FAILURE -> {
                Log.e("SMS_STATUS", "Generic Failure for $phoneNumber")
                Toast.makeText(context, "SOS SMS Failed (Generic) for $phoneNumber", Toast.LENGTH_SHORT).show()
            }
            SmsManager.RESULT_ERROR_NO_SERVICE -> {
                Log.e("SMS_STATUS", "No Service for $phoneNumber")
                Toast.makeText(context, "SOS SMS Failed (No Service)", Toast.LENGTH_SHORT).show()
            }
            SmsManager.RESULT_ERROR_NULL_PDU -> {
                Log.e("SMS_STATUS", "Null PDU for $phoneNumber")
            }
            SmsManager.RESULT_ERROR_RADIO_OFF -> {
                Log.e("SMS_STATUS", "Radio Off for $phoneNumber")
                Toast.makeText(context, "SOS SMS Failed (Radio Off)", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Log.e("SMS_STATUS", "Unknown Error for $phoneNumber: $resultCode")
                Toast.makeText(context, "SOS SMS Failed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

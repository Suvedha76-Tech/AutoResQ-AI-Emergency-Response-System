package com.roadsos.app.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roadsos.app.data.model.SOSAlert
import com.roadsos.app.viewmodel.MainViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

@Composable
fun LiveSOSMonitoringScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val alerts by viewModel.liveSOSAlerts.collectAsStateWithLifecycle()
    val myLoc by viewModel.currentLocation.collectAsStateWithLifecycle()
    val context = LocalContext.current
    
    val neonRed = Color(0xFFFF003C)
    val neonCyan = Color(0xFF00F2FF)
    val darkBg = Color(0xFF020205)
    val glassBg = Color(0xCC0D0D1A)

    Box(modifier = Modifier.fillMaxSize().background(darkBg)) {
        // RADAR SCANNING BACKGROUND EFFECT
        RadarScanningEffect(neonRed)

        Column(modifier = Modifier.fillMaxSize()) {
            // HEADER
            Surface(
                modifier = Modifier.fillMaxWidth().statusBarsPadding(),
                color = Color.Transparent
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.background(glassBg, CircleShape)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("LIVE SOS MONITOR", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ActiveSOSPulse()
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("${alerts.size} ACTIVE EMERGENCIES", color = neonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // MAIN CONTENT
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (alerts.isEmpty()) {
                    item {
                        EmptySOSState(neonCyan)
                    }
                }

                items(alerts, key = { it.id }) { alert ->
                    SOSRescueCard(
                        alert = alert,
                        onAccept = { viewModel.acceptSOS(alert.id) },
                        onResolve = { viewModel.resolveSOS(alert.id) },
                        neonRed = neonRed,
                        glassBg = glassBg
                    )
                }
            }

            // COMPACT GLOBAL MAP
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp)
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, neonRed.copy(0.3f))
            ) {
                SOSMapView(alerts, myLoc)
            }
        }
    }
}

@Composable
fun SOSRescueCard(
    alert: SOSAlert,
    onAccept: () -> Unit,
    onResolve: () -> Unit,
    neonRed: Color,
    glassBg: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = glassBg),
        border = BorderStroke(1.dp, neonRed.copy(0.4f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Pulse Profile
                Box(contentAlignment = Alignment.Center) {
                    ActiveSOSPulse(size = 48.dp)
                    Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.Gray)) {
                        Icon(Icons.Default.Person, null, modifier = Modifier.align(Alignment.Center), tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(alert.username, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(alert.emergencyType, color = neonRed, fontSize = 12.sp, fontWeight = FontWeight.Black)
                }
                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(neonRed.copy(0.2f)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(alert.riskLevel, color = neonRed, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.LocationOn, null, tint = neonRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(alert.address, color = Color.White.copy(0.7f), fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                SOSInfoItem(Icons.Default.People, "${alert.helperCount} HELPERS", Color(0xFF00F2FF))
                SOSInfoItem(Icons.Default.Timer, alert.responderETA, Color(0xFFFF9800))
                SOSInfoItem(Icons.Default.BatteryChargingFull, "${alert.batteryLevel}%", Color(0xFF00FF9D))
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onAccept,
                    modifier = Modifier.weight(1f).height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F2FF)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("ACCEPT RESCUE", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onResolve,
                    modifier = Modifier.weight(0.6f).height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    border = BorderStroke(1.dp, Color.White.copy(0.3f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("RESOLVE", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun SOSInfoItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color.copy(0.7f), modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SOSMapView(alerts: List<SOSAlert>, myLoc: Pair<Double, Double>?) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            Configuration.getInstance().load(context, context.getSharedPreferences("osm", Context.MODE_PRIVATE))
            MapView(context).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                setMultiTouchControls(true)
                controller.setZoom(14.0)
                
                // Dark Theme Map Filter
                val inverseMatrix = floatArrayOf(
                    -1.0f, 0.0f, 0.0f, 0.0f, 255.0f,
                    0.0f, -1.0f, 0.0f, 0.0f, 255.0f,
                    0.0f, 0.0f, -1.0f, 0.0f, 255.0f,
                    0.0f, 0.0f, 0.0f, 1.0f, 0.0f
                )
                overlayManager.tilesOverlay.setColorFilter(android.graphics.ColorMatrixColorFilter(inverseMatrix))
            }
        },
        update = { mapView ->
            mapView.overlays.clear()
            
            myLoc?.let { loc ->
                val myMarker = Marker(mapView).apply {
                    position = GeoPoint(loc.first, loc.second)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    icon = androidx.appcompat.content.res.AppCompatResources.getDrawable(context, android.R.drawable.presence_online)
                }
                mapView.overlays.add(myMarker)
            }

            alerts.forEach { alert ->
                val marker = Marker(mapView).apply {
                    position = GeoPoint(alert.latitude, alert.longitude)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    icon = androidx.appcompat.content.res.AppCompatResources.getDrawable(context, android.R.drawable.ic_notification_overlay)
                    title = alert.username
                }
                mapView.overlays.add(marker)
            }
            
            if (alerts.isNotEmpty()) {
                mapView.controller.animateTo(GeoPoint(alerts.first().latitude, alerts.first().longitude))
            }
            mapView.invalidate()
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun ActiveSOSPulse(size: androidx.compose.ui.unit.Dp = 10.dp) {
    val infiniteTransition = rememberInfiniteTransition()
    val scale by infiniteTransition.animateFloat(0.6f, 1.4f, infiniteRepeatable(tween(1000), RepeatMode.Reverse))
    val alpha by infiniteTransition.animateFloat(0.2f, 0.8f, infiniteRepeatable(tween(1000), RepeatMode.Reverse))
    
    Box(
        modifier = Modifier
            .size(size)
            .scale(scale)
            .background(Color(0xFFFF003C).copy(alpha = alpha), CircleShape)
    )
}

@Composable
fun RadarScanningEffect(color: Color) {
    val infiniteTransition = rememberInfiniteTransition()
    val rotation by infiniteTransition.animateFloat(0f, 360f, infiniteRepeatable(tween(5000, easing = LinearEasing)))
    
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize().rotate(rotation)) {
            drawCircle(
                brush = Brush.sweepGradient(listOf(Color.Transparent, color.copy(0.1f), Color.Transparent)),
                radius = size.minDimension
            )
        }
    }
}

@Composable
fun EmptySOSState(color: Color) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Shield, null, tint = color.copy(0.2f), modifier = Modifier.size(100.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("SCANNING FOR SOS SIGNALS", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Black)
        Text("No active emergencies in your area", color = Color.Gray, fontSize = 10.sp)
    }
}

package com.roadsos.app.viewmodel

import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.roadsos.app.data.local.UserPreferences
import com.roadsos.app.data.model.*
import com.roadsos.app.repository.EmergencyRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class EmergencyViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val repo = EmergencyRepository()
    private val sosRepo = com.roadsos.app.repository.SOSRepository(application)
    private val userPrefs = UserPreferences(context)
    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()

    private val _emergencyState = MutableStateFlow(EmergencyState())
    val emergencyState: StateFlow<EmergencyState> = _emergencyState.asStateFlow()

    private val _currentEmergency = MutableStateFlow<Emergency?>(null)
    val currentEmergency: StateFlow<Emergency?> = _currentEmergency.asStateFlow()

    private val _helpers = MutableStateFlow<List<Helper>>(emptyList())
    val helpers: StateFlow<List<Helper>> = _helpers.asStateFlow()

    private var mediaRecorder: MediaRecorder? = null
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var trackingJob: Job? = null
    private var escalationJob: Job? = null

    fun init(lat: Double, lng: Double, isDemo: Boolean) {
        _emergencyState.update {
            it.copy(
                latitude = lat,
                longitude = lng,
                isDemoMode = isDemo,
                address = "Fetching Accurate GPS..."
            )
        }
    }

    private fun getAIStatus(emergency: Emergency?, helpers: List<Helper>): String {
        if (emergency == null) return "Analyzing emergency context..."
        if (emergency.status == "RESOLVED") return "Emergency Resolved. User is safe."
        if (helpers.isEmpty()) {
            return if (emergency.status == "ESCALATED") "Escalating emergency alert radius to 10km..."
            else "SOS Broadcasted. Searching for helpers..."
        }
        val primary = helpers.find { it.userId == emergency.primaryHelperId }
        return if (primary != null) "Fastest responder ${primary.name} assigned and approaching."
        else "${helpers.size} helpers responding. Community rescue active."
    }

    fun triggerSOS() {
        val state = _emergencyState.value
        Log.d("SOS_FLOW", "SOS Triggered. Starting AI-powered community rescue...")

        viewModelScope.launch {
            _emergencyState.update { it.copy(isLoading = true, statusMessage = "Alerting emergency contacts & nearby community...") }

            sendEmergencySMS(state.latitude, state.longitude)
            startEvidenceCollection()

            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            var finalLat = state.latitude
            var finalLng = state.longitude

            try {
                val location = withTimeout(3500) {
                    fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                }
                if (location != null) {
                    finalLat = location.latitude
                    finalLng = location.longitude
                }
            } catch (e: Exception) {
                Log.e("SOS_FLOW", "Location fetch error: ${e.message}")
            }

            val phone = userPrefs.userPhone.first() 
            val userId = if (state.isDemoMode) "demo_$phone" else phone
            
            // Push to NEW real-time SOS collection for global dashboard
            sosRepo.triggerSOS(
                userId = userId,
                username = phone,
                lat = finalLat,
                lng = finalLng,
                batteryLevel = 90
            )

            val result = repo.createEmergency(
                userId = userId,
                latitude = finalLat,
                longitude = finalLng,
                userName = phone
            )

            result.onSuccess { id ->
                _emergencyState.update { it.copy(isLoading = false, emergencyId = id, sosSent = true, statusMessage = "SOS Broadcasted. Searching for helpers...") }
                listenToEmergency(id)
                listenToHelpers(id)
                startVictimTracking(id)
                startEscalationTimer(id)
            }.onFailure {
                _emergencyState.update { s -> s.copy(isLoading = false, error = it.message, statusMessage = "SOS SMS Sent, Cloud Alert Failed") }
            }
        }
    }

    fun markAsSafe() {
        val id = _emergencyState.value.emergencyId ?: return
        viewModelScope.launch {
            repo.updateEmergencyStatus(id, "RESOLVED")
            
            _emergencyState.update { it.copy(statusMessage = "Emergency Resolved. You are safe.") }
            delay(2000)
            stopAllProcesses()
        }
    }

    private fun stopAllProcesses() {
        trackingJob?.cancel()
        escalationJob?.cancel()
        mediaRecorder?.release()
        mediaRecorder = null
    }

    private fun listenToEmergency(id: String) {
        viewModelScope.launch {
            repo.listenToEmergency(id).collect { emergency ->
                _currentEmergency.value = emergency
                emergency?.let {
                    val aiStatus = getAIStatus(it, _helpers.value)
                    _emergencyState.update { s -> s.copy(statusMessage = aiStatus) }
                }
            }
        }
    }

    private fun startEscalationTimer(id: String) {
        escalationJob?.cancel()
        escalationJob = viewModelScope.launch {
            delay(30000)
            val current = _currentEmergency.value
            if (current != null && current.respondersCount == 0 && current.status != "RESOLVED") {
                Log.d("SOS_FLOW", "No helpers in 30s. Escalating...")
                repo.escalateEmergency(id, 10.0, "HIGH")
            }
        }
    }

    private fun startEvidenceCollection() {
        viewModelScope.launch {
            try {
                startAudioRecording()
                delay(1000)
                captureImage(CameraSelector.LENS_FACING_BACK, "back")
            } catch (e: Exception) {
                Log.e("EVIDENCE", "Evidence collection failed: ${e.message}")
            }
        }
    }

    private fun startAudioRecording() {
        val fileName = "${context.externalCacheDir?.absolutePath}/audio_sos_${System.currentTimeMillis()}.m4a"
        mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION") MediaRecorder()
        }.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(fileName)
            try {
                prepare()
                start()
                Log.d("EVIDENCE", "Audio recording started")
                viewModelScope.launch {
                    delay(10000)
                    stopAudioRecording(fileName)
                }
            } catch (e: Exception) {
                Log.e("EVIDENCE", "Audio recording failed", e)
            }
        }
    }

    private fun stopAudioRecording(filePath: String) {
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
            uploadFileToStorage(File(filePath), "audio")
        } catch (e: Exception) {
            Log.e("EVIDENCE", "Stop audio failed", e)
        }
    }

    private fun captureImage(lensFacing: Int, suffix: String) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val imageCapture = ImageCapture.Builder().build()
            val cameraSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            Log.d("EVIDENCE", "Attempting image capture: $suffix")
        }, ContextCompat.getMainExecutor(context))
    }

    private fun uploadFileToStorage(file: File, type: String) {
        val emergencyId = _emergencyState.value.emergencyId ?: return
        val storageRef = storage.reference.child("evidence/$emergencyId/${file.name}")
        
        viewModelScope.launch {
            try {
                storageRef.putFile(Uri.fromFile(file)).await()
                val url = storageRef.downloadUrl.await()
                repo.addEvidenceUrl(emergencyId, url.toString(), type)
            } catch (e: Exception) {
                Log.e("EVIDENCE", "Upload failed", e)
            }
        }
    }

    private fun listenToHelpers(emergencyId: String) {
        viewModelScope.launch {
            repo.listenToHelpers(emergencyId).collect { helperList ->
                _helpers.value = helperList
                val current = _currentEmergency.value
                val aiStatus = getAIStatus(current, helperList)
                _emergencyState.update { it.copy(statusMessage = aiStatus) }
                
                if (helperList.isNotEmpty()) {
                    escalationJob?.cancel()
                }
            }
        }
    }

    private fun startVictimTracking(emergencyId: String) {
        trackingJob?.cancel()
        trackingJob = viewModelScope.launch {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            while (isActive) {
                try {
                    val location = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                    if (location != null) {
                        db.collection("emergencies").document(emergencyId)
                            .update("latitude", location.latitude, "longitude", location.longitude)
                    }
                } catch (e: Exception) {
                    Log.e("TRACKING", "Victim tracking failed", e)
                }
                delay(5000)
            }
        }
    }

    private suspend fun sendEmergencySMS(lat: Double, lng: Double) {
        try {
            val localC1 = userPrefs.contact1.first()
            val localC2 = userPrefs.contact2.first()
            val userPhone = userPrefs.userPhone.first()

            val rawContacts = mutableSetOf<String>()
            if (localC1.isNotBlank()) rawContacts.add(localC1)
            if (localC2.isNotBlank()) rawContacts.add(localC2)

            if (userPhone.isNotBlank()) {
                try {
                    val doc = db.collection("users").document(userPhone).get().await()
                    doc.getString("contact1")?.let { if (it.isNotBlank()) rawContacts.add(it) }
                    doc.getString("contact2")?.let { if (it.isNotBlank()) rawContacts.add(it) }
                } catch (e: Exception) {}
            }

            val finalizedContacts = rawContacts.map { input ->
                val digits = input.filter { it.isDigit() || it == '+' }
                if (digits.length == 10 && !digits.startsWith("+")) "+91$digits" else digits
            }.filter { it.length >= 10 }

            val mapsUrl = "https://maps.google.com/?q=$lat,$lng"
            val msg = "🚨 EMERGENCY ALERT!\nI need help at this location:\n$mapsUrl\nSent via RoadSoS app."

            val smsManager: SmsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            finalizedContacts.forEach { contact ->
                val sentPI = PendingIntent.getBroadcast(
                    context, contact.hashCode(), 
                    Intent("SMS_SENT").apply { putExtra("phone", contact); `package` = context.packageName },
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val parts = smsManager.divideMessage(msg)
                val sentIntents = ArrayList<PendingIntent>()
                for (i in parts.indices) sentIntents.add(sentPI)
                smsManager.sendMultipartTextMessage(contact, null, parts, sentIntents, null)
            }
        } catch (e: Exception) {
            Log.e("SMS_DEBUG", "SMS failed: ${e.message}")
            _emergencyState.update { it.copy(statusMessage = "SOS SMS Failed") }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopAllProcesses()
        cameraExecutor.shutdown()
    }
}

data class EmergencyState(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val isDemoMode: Boolean = false,
    val address: String? = null,
    val isLoading: Boolean = false,
    val emergencyId: String? = null,
    val sosSent: Boolean = false,
    val statusMessage: String? = null,
    val error: String? = null
)

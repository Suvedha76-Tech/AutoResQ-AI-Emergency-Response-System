package com.roadsos.app.repository

import android.util.Log
import com.roadsos.app.data.model.EmergencyService
import com.roadsos.app.data.model.ServiceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.*
import kotlin.random.Random

class EmergencyServiceRepository {

    suspend fun getNearbyServices(lat: Double, lng: Double, type: ServiceType): List<EmergencyService> = withContext(Dispatchers.IO) {
        try {
            val amenity = when (type) {
                ServiceType.HOSPITAL -> "hospital"
                ServiceType.POLICE -> "police"
                ServiceType.FUEL -> "fuel"
                ServiceType.EV_CHARGING -> "charging_station"
                ServiceType.PARKING -> "parking"
            }

            val query = "[out:json];node[\"amenity\"=\"$amenity\"](around:10000,$lat,$lng);out;"
            val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
            val url = URL("https://overpass-api.de/api/interpreter?data=$encodedQuery")
            
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            
            if (connection.responseCode == 200) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val jsonObject = JSONObject(response)
                val elements = jsonObject.optJSONArray("elements") ?: return@withContext getFallbackServices(lat, lng, type)
                
                val services = mutableListOf<EmergencyService>()
                for (i in 0 until elements.length()) {
                    val element = elements.getJSONObject(i)
                    val id = element.optLong("id").toString()
                    val sLat = element.optDouble("lat")
                    val sLng = element.optDouble("lon")
                    val tags = element.optJSONObject("tags")
                    
                    val name = tags?.optString("name") ?: getDefaultName(type)
                    val address = tags?.optString("addr:street") ?: "Nearby Location"
                    val phone = tags?.optString("phone") ?: tags?.optString("contact:phone") ?: getDefaultPhone(type)
                    
                    val distKm = calculateDistance(lat, lng, sLat, sLng)
                    services.add(
                        EmergencyService(
                            id = id,
                            name = name,
                            type = type,
                            latitude = sLat,
                            longitude = sLng,
                            address = address,
                            phone = phone,
                            distance = distKm,
                            distanceStr = formatDistance(distKm),
                            eta = (distKm * 3 + 2).toInt().coerceAtLeast(1),
                            status = if (Random.nextBoolean()) "Available" else "Busy",
                            rating = 4.0f + (Random.nextFloat() * 1.0f)
                        )
                    )
                }
                
                if (services.isEmpty()) {
                    getFallbackServices(lat, lng, type)
                } else {
                    services.sortedBy { it.distance }
                }
            } else {
                getFallbackServices(lat, lng, type)
            }
        } catch (e: Exception) {
            Log.e("SERVICE_REPO", "Failed to fetch $type: ${e.message}")
            getFallbackServices(lat, lng, type)
        }
    }

    private fun getDefaultName(type: ServiceType) = when (type) {
        ServiceType.HOSPITAL -> "Medical Center"
        ServiceType.POLICE -> "Police Post"
        ServiceType.FUEL -> "Gas Station"
        ServiceType.EV_CHARGING -> "EV Charge Point"
        ServiceType.PARKING -> "Safe Parking"
    }

    private fun getDefaultPhone(type: ServiceType) = when (type) {
        ServiceType.HOSPITAL -> "108"
        ServiceType.POLICE -> "100"
        else -> "N/A"
    }

    private fun getFallbackServices(lat: Double, lng: Double, type: ServiceType): List<EmergencyService> {
        val names = when (type) {
            ServiceType.HOSPITAL -> listOf("City Hospital", "Metro Clinic", "LifeCare ER")
            ServiceType.POLICE -> listOf("District Police Station", "Cyber Cell HQ", "Local Police Outpost")
            ServiceType.FUEL -> listOf("Shell Station", "BP Fuel Hub", "Indian Oil")
            ServiceType.EV_CHARGING -> listOf("Tesla Supercharger", "Tata Power EZ", "Aether Grid")
            ServiceType.PARKING -> listOf("Secure Multi-level Parking", "Public Parking Lot", "Hotel Parking (Safe)")
        }
        
        return names.mapIndexed { index, name ->
            val offsetLat = lat + (index - 1) * 0.01 
            val offsetLng = lng + (index - 1) * 0.012
            val distKm = calculateDistance(lat, lng, offsetLat, offsetLng)
            EmergencyService(
                id = "mock_${type}_$index",
                name = name,
                type = type,
                latitude = offsetLat,
                longitude = offsetLng,
                address = "Simulated Location",
                phone = getDefaultPhone(type),
                distance = distKm,
                distanceStr = formatDistance(distKm),
                eta = (distKm * 3 + 1).toInt().coerceAtLeast(1),
                status = "Open Now",
                rating = 4.5f
            )
        }.sortedBy { it.distance }
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    private fun formatDistance(km: Double): String {
        return if (km < 1.0) {
            "${(km * 1000).toInt()}m"
        } else {
            java.util.Locale.US.let { String.format(it, "%.1f km", km) }
        }
    }
}

package com.roadsos.app.service

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.roadsos.app.MainActivity
import com.roadsos.app.ui.screens.EmergencyAlertActivity
import com.roadsos.app.viewmodel.AIVoiceViewModel
import java.util.*

class VoiceDetectionService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var recognizerIntent: Intent? = null
    private val handler = Handler(Looper.getMainLooper())

    private val emergencyPhrases = listOf(
        "help", "help me", "save me", "emergency", "sos", 
        "accident", "someone help", "please help"
    )

    companion object {
        private const val CHANNEL_ID = "voice_protection_channel"
        private const val NOTIFICATION_ID = 1002
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("AI Voice Protection Active"))
        initSpeechRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra("mode") ?: "NORMAL"
        Log.d("VoiceService", "Service started with mode: $mode")
        startListening()
        return START_STICKY
    }

    private fun initSpeechRecognizer() {
        handler.post {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Log.d("VoiceService", "Ready for speech")
                        AIVoiceViewModel.updateState { it.copy(isListening = true) }
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {
                        AIVoiceViewModel.updateState { it.copy(rmsdB = rmsdB) }
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                            SpeechRecognizer.ERROR_NETWORK -> "Network error"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No match"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Service busy"
                            SpeechRecognizer.ERROR_SERVER -> "Server error"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input"
                            else -> "Unknown error"
                        }
                        Log.e("VoiceService", "Error: $message ($error)")
                        
                        // Restart listening if interrupted
                        if (error != SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                            handler.postDelayed({ startListening() }, 1000)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        matches?.forEach { phrase ->
                            Log.d("VoiceService", "Detected: $phrase")
                            if (checkEmergency(phrase)) {
                                triggerSOS()
                                return@forEach
                            }
                        }
                        startListening() // Continue listening
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        matches?.forEach { phrase ->
                            if (checkEmergency(phrase)) {
                                triggerSOS()
                                return@forEach
                            }
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    // Some devices need this for background
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
            }
        }
    }

    private fun startListening() {
        handler.post {
            try {
                speechRecognizer?.startListening(recognizerIntent)
            } catch (e: Exception) {
                Log.e("VoiceService", "Start listening failed", e)
            }
        }
    }

    private fun checkEmergency(phrase: String): Boolean {
        val p = phrase.lowercase()
        return emergencyPhrases.any { p.contains(it) }
    }

    private fun triggerSOS() {
        Log.d("VoiceService", "EMERGENCY DETECTED BY VOICE!")
        AIVoiceViewModel.onDangerDetected()
        
        // Also trigger the activity as before
        val intent = Intent(this, EmergencyAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("isDemoMode", false)
        }
        startActivity(intent)
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "AI Voice Protection", NotificationManager.IMPORTANCE_LOW)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RoadSoS AI Voice Protection")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        AIVoiceViewModel.updateState { it.copy(isListening = false, rmsdB = 0f) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

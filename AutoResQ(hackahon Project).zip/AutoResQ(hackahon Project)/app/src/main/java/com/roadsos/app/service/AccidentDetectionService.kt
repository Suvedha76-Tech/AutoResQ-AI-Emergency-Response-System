package com.roadsos.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.roadsos.app.MainActivity
import com.roadsos.app.data.local.UserPreferences
import com.roadsos.app.data.model.AccidentEvent
import com.roadsos.app.data.model.EmergencyStatus
import com.roadsos.app.repository.EmergencyRepository
import com.roadsos.app.ui.screens.EmergencyAlertActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlin.math.sqrt

class AccidentDetectionService : Service(), SensorEventListener {

    companion object {
        private const val TAG = "AccidentDetection"
        private const val NOTIFICATION_ID = 1001
        private const val ALERT_NOTIFICATION_ID = 2002
        private const val CHANNEL_ID = "accident_detection_channel"
        private const val ALERT_CHANNEL_ID = "roadsos_community_alerts"
        const val ACCIDENT_THRESHOLD = 25f
        const val SHAKE_THRESHOLD = 15f
        const val SPEED_DROP_THRESHOLD = 15f

        private val _accidentEvents = MutableSharedFlow<AccidentEvent>(replay = 0)
        val accidentEvents = _accidentEvents.asSharedFlow()

        fun simulateDemoAccident(context: Context) {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    val lat = location?.latitude ?: 13.0827
                    val lng = location?.longitude ?: 80.2707
                    val intent = Intent(context, EmergencyAlertActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("latitude", lat)
                        putExtra("longitude", lng)
                        putExtra("isDemoMode", true)
                    }
                    context.startActivity(intent)
                }
            } catch (e: SecurityException) {
                // Fallback to fixed if no permission
                val intent = Intent(context, EmergencyAlertActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("latitude", 13.0827)
                    putExtra("longitude", 80.2707)
                    putExtra("isDemoMode", true)
                }
                context.startActivity(intent)
            }
        }
    }

    private lateinit var sensorManager: SensorManager
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var accelerometer: Sensor? = null
    private var lastLocation: Location? = null
    private var lastSpeed: Float = 0f
    private var lastAcceleration: Float = 0f
    
    private val repo = EmergencyRepository()
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var alertListenerJob: Job? = null

    private val accelerationWindow = ArrayDeque<Float>(5)

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        
        createNotificationChannels()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        
        registerSensors()
        startLocationUpdates()
        startEmergencyMonitor()
    }

    private fun startEmergencyMonitor() {
        alertListenerJob?.cancel()
        alertListenerJob = serviceScope.launch {
            val userPrefs = UserPreferences(this@AccidentDetectionService)
            repo.listenToActiveEmergencies().collect { emergencies ->
                val myPhone = userPrefs.userPhone.first()
                val myLoc = lastLocation ?: return@collect
                
                emergencies.forEach { emergency ->
                    if (emergency.userId == myPhone || emergency.status == "RESOLVED") return@forEach
                    
                    val dist = repo.calculateDistance(myLoc.latitude, myLoc.longitude, emergency.latitude, emergency.longitude)
                    if (dist <= emergency.radius) {
                        showCommunityAlertNotification(emergency, dist)
                    }
                }
            }
        }
    }

    private fun showCommunityAlertNotification(emergency: com.roadsos.app.data.model.Emergency, distance: Double) {
        val distStr = repo.formatDistance(distance)
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("emergencyId", emergency.emergencyId)
        }
        val pendingIntent = PendingIntent.getActivity(this, emergency.emergencyId.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("🚨 EMERGENCY NEARBY")
            .setContentText("${emergency.username} needs help $distStr away!")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 500, 200, 500))
            .build()

        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(emergency.emergencyId.hashCode(), notification)
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        
        val channel1 = NotificationChannel(CHANNEL_ID, "Accident Detection", NotificationManager.IMPORTANCE_LOW)
        val channel2 = NotificationChannel(ALERT_CHANNEL_ID, "Community Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        
        manager.createNotificationChannel(channel1)
        manager.createNotificationChannel(channel2)
    }

    private fun registerSensors() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).build()
        try {
            fusedLocationClient.requestLocationUpdates(request, object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    val location = result.lastLocation ?: return
                    lastLocation = location
                    lastSpeed = location.speed * 3.6f
                }
            }, Looper.getMainLooper())
        } catch (e: SecurityException) {}
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
        val totalAcceleration = sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH

        if (accelerationWindow.size >= 5) accelerationWindow.removeFirst()
        accelerationWindow.addLast(totalAcceleration)
        val smoothed = accelerationWindow.average().toFloat()

        if (smoothed > ACCIDENT_THRESHOLD) {
            triggerEmergencyScreen(smoothed, lastLocation?.latitude ?: 0.0, lastLocation?.longitude ?: 0.0)
        }
        lastAcceleration = smoothed
    }

    private fun triggerEmergencyScreen(acceleration: Float, lat: Double, lng: Double) {
        val intent = Intent(this, EmergencyAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("latitude", lat); putExtra("longitude", lng)
            putExtra("acceleration", acceleration); putExtra("isDemoMode", false)
        }
        startActivity(intent)
    }

    private fun buildForegroundNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RoadSoS Community Rescue Active")
            .setContentText("Monitoring for accidents & nearby alerts...")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setOngoing(true)
            .build()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        alertListenerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }
}

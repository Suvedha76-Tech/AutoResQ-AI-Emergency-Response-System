package com.roadsos.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.roadsos.app.viewmodel.*
import kotlinx.coroutines.delay
import java.util.*

@Composable
fun AIAssistantScreen(mainViewModel: MainViewModel, navController: androidx.navigation.NavController) {
    val aiViewModel: AIAssistantViewModel = viewModel()
    val uiState by aiViewModel.uiState.collectAsState()
    val context = LocalContext.current
    val listState = rememberLazyListState()
    
    var textInput by remember { mutableStateOf("") }
    var showRiskPanel by remember { mutableStateOf(false) }
    
    // Speech Recognition
    val speechRecognizer = remember { SpeechRecognizer.createSpeechRecognizer(context) }
    val speechIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }
    }

    DisposableEffect(Unit) {
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { aiViewModel.setOrbState(OrbState.LISTENING) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { aiViewModel.updateRms(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { aiViewModel.setOrbState(OrbState.THINKING) }
            override fun onError(error: Int) { aiViewModel.setOrbState(OrbState.IDLE) }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) aiViewModel.onUserMessage(matches[0])
                else aiViewModel.setOrbState(OrbState.IDLE)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
        speechRecognizer.setRecognitionListener(listener)
        onDispose { speechRecognizer.destroy() }
    }

    LaunchedEffect(uiState.chatHistory.size) {
        if (uiState.chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(uiState.chatHistory.size)
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0A0A12))) {
        // Futuristic Glow Background
        val bgGlowColor = when(uiState.orbState) {
            OrbState.EMERGENCY -> Color(0x44E24B4A)
            OrbState.LISTENING -> Color(0x4400F2FF)
            else -> Color(0x224285F4)
        }
        
        Box(modifier = Modifier.fillMaxSize().background(Brush.radialGradient(listOf(bgGlowColor, Color.Transparent), radius = 1500f)))

        Column(modifier = Modifier.fillMaxSize()) {
            AIHeader(uiState.orbState)

            Box(modifier = Modifier.weight(1f)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    item {
                        InteractiveOrb(uiState.orbState, uiState.rmsdB)
                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    item {
                        AdvancedActionGrid(
                            onAction = { aiViewModel.onUserMessage(it) },
                            onRiskClick = { 
                                showRiskPanel = true 
                                aiViewModel.analyzeRouteRisk()
                            }
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    items(uiState.chatHistory) { message ->
                        ChatBubble(message, onActionClick = { action ->
                            handleAIAction(action, context, aiViewModel, navController)
                        })
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    if (uiState.isTyping) {
                        item { TypingIndicator() }
                    }
                }

                // Route Risk Prediction Overlay
                this@Column.AnimatedVisibility(
                    visible = showRiskPanel,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    RouteRiskPanel(uiState.routeRisk, onClose = { showRiskPanel = false })
                }
            }

            BottomInputArea(
                text = textInput,
                onTextChange = { textInput = it },
                onSend = { aiViewModel.onUserMessage(textInput); textInput = "" },
                onMicClick = { speechRecognizer.startListening(speechIntent) },
                isListening = uiState.orbState == OrbState.LISTENING
            )
        }
    }
}

@Composable
fun AIHeader(state: OrbState) {
    Row(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("RESQ AI ASSISTANT", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                val statusColor = if (state == OrbState.EMERGENCY) Color(0xFFE24B4A) else Color(0xFF00FF9D)
                val infiniteTransition = rememberInfiniteTransition()
                val alpha by infiniteTransition.animateFloat(0.4f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse))
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(statusColor.copy(alpha = alpha)))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (state == OrbState.EMERGENCY) "EMERGENCY PROTOCOL" else "LIVE MONITORING ACTIVE", color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun InteractiveOrb(state: OrbState, rms: Float) {
    val infiniteTransition = rememberInfiniteTransition()
    val orbColor = when(state) {
        OrbState.EMERGENCY -> Color(0xFFE24B4A)
        OrbState.LISTENING -> Color(0xFF00F2FF)
        OrbState.THINKING -> Color(0xFFBB86FC)
        OrbState.RESPONDING -> Color(0xFF4285F4)
        else -> Color(0xFF00F2FF)
    }

    val scale by infiniteTransition.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(2500), RepeatMode.Reverse))
    val rotation by infiniteTransition.animateFloat(0f, 360f, infiniteRepeatable(tween(10000, easing = LinearEasing)))

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
        // Holographic Rings
        repeat(3) { i ->
            Box(modifier = Modifier
                .size((160 + i * 20).dp)
                .graphicsLayer { rotationZ = if(i%2==0) rotation else -rotation }
                .border(1.dp, Brush.sweepGradient(listOf(Color.Transparent, orbColor.copy(alpha = 0.5f), Color.Transparent)), CircleShape)
            )
        }

        // Pulse Glow
        Box(modifier = Modifier.size(120.dp).scale(scale).blur(30.dp).background(orbColor.copy(alpha = 0.3f), CircleShape))

        // Core AI Face
        Box(
            modifier = Modifier
                .size(90.dp)
                .scale(scale)
                .background(Brush.linearGradient(listOf(Color.White, orbColor)), CircleShape)
                .border(2.dp, Color.White.copy(0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            val icon = when(state) {
                OrbState.EMERGENCY -> Icons.Default.Warning
                OrbState.LISTENING -> Icons.Default.GraphicEq
                OrbState.THINKING -> Icons.Default.AutoAwesome
                else -> Icons.Default.Face
            }
            Icon(icon, null, tint = Color(0xFF0A0A12), modifier = Modifier.size(40.dp))
        }

        // Realtime Waveform
        if (state == OrbState.LISTENING || state == OrbState.RESPONDING) {
            Row(modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(12) {
                    val h by animateFloatAsState(if(state == OrbState.LISTENING) (rms/10f)+0.2f else kotlin.random.Random.nextFloat() * 0.5f + 0.3f, tween(150))
                    Box(modifier = Modifier.width(3.dp).height((25 * h + 5).dp).background(orbColor, CircleShape))
                }
            }
        }
    }
}

@Composable
fun AdvancedActionGrid(onAction: (String) -> Unit, onRiskClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        // Premium Risk Prediction Card
        Surface(
            modifier = Modifier.fillMaxWidth().height(100.dp).clickable { onRiskClick() },
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF151525),
            border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(Color(0xFF00F2FF), Color(0xFF4285F4))))
        ) {
            Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(50.dp).background(Color(0x1A00F2FF), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Shield, null, tint = Color(0xFF00F2FF), modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("🛡 AI ROUTE RISK PREDICTION", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text("Live safety analysis & threat detection", color = Color(0x88FFFFFF), fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
            }
        }
        
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val items = listOf("Is road safe?" to Icons.Default.Traffic, "Find Hospital" to Icons.Default.LocalHospital, "SOS" to Icons.Default.Sos)
            items.forEach { (label, icon) ->
                QuickActionCard(label, icon) { onAction(label) }
            }
        }
    }
}

@Composable
fun RowScope.QuickActionCard(label: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.weight(1f).height(70.dp).clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = Color(0x0DFFFFFF),
        border = BorderStroke(0.5.dp, Color(0x1AFFFFFF))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = if(label == "SOS") Color(0xFFE24B4A) else Color(0xFF00F2FF), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(label, fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage, onActionClick: (AIAction) -> Unit) {
    val alignment = if (message.isUser) Alignment.End else Alignment.Start
    val bgColor = if (message.isUser) Color(0xFF4285F4).copy(0.2f) else Color(0x0DFFFFFF)
    
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = bgColor,
            border = BorderStroke(1.dp, if(message.isUser) Color(0xFF4285F4).copy(0.4f) else Color(0x1AFFFFFF))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(message.text, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
                
                if (message.actions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        message.actions.forEach { action ->
                            Button(
                                onClick = { onActionClick(action) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if(action.type == ActionType.SOS) Color(0xFFE24B4A) else Color(0xFF00F2FF).copy(0.2f),
                                    contentColor = if(action.type == ActionType.SOS) Color.White else Color(0xFF00F2FF)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text(action.label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RouteRiskPanel(state: RouteRiskState, onClose: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D1A)),
        border = BorderStroke(1.dp, Color(0xFF00F2FF).copy(0.3f))
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AI RISK ANALYSIS", color = Color(0xFF00F2FF), fontWeight = FontWeight.Black, fontSize = 14.sp)
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = Color.Gray) }
            }
            
            if (state.isAnalyzing) {
                Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF00F2FF))
                    Text("Scanning Route...", color = Color.White, modifier = Modifier.padding(top = 80.dp), fontSize = 12.sp)
                }
            } else {
                Row(modifier = Modifier.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(progress = { state.safetyScore/100f }, modifier = Modifier.size(80.dp), color = Color(0xFF00FF9D), strokeWidth = 8.dp)
                        Text("${state.safetyScore}%", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column {
                        Text("Route Safety Score", color = Color.Gray, fontSize = 12.sp)
                        Text("High Confidence", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }

                Divider(color = Color(0x1AFFFFFF), modifier = Modifier.padding(vertical = 8.dp))

                RiskItem("Traffic Severity", state.trafficSeverity, if(state.trafficSeverity == "LOW") Color(0xFF00FF9D) else Color(0xFFE24B4A))
                RiskItem("Accident-prone Zones", "${state.riskZones} Detected", if(state.riskZones == 0) Color(0xFF00FF9D) else Color(0xFFFF9800))
                RiskItem("Suggested Path", "Alternate Route via 5th Ave", Color(0xFF00F2FF))
            }
        }
    }
}

@Composable
fun RiskItem(label: String, value: String, color: Color) {
    Row(modifier = Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(10.dp))
        Text(label, color = Color(0x88FFFFFF), fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BottomInputArea(text: String, onTextChange: (String) -> Unit, onSend: () -> Unit, onMicClick: () -> Unit, isListening: Boolean) {
    Surface(modifier = Modifier.fillMaxWidth(), color = Color(0xFF0D0D1A), border = BorderStroke(0.5.dp, Color(0x1AFFFFFF))) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = text, onValueChange = onTextChange, modifier = Modifier.weight(1f),
                placeholder = { Text("Ask ResQ AI...", color = Color.Gray, fontSize = 14.sp) },
                colors = TextFieldDefaults.colors(focusedContainerColor = Color(0x0DFFFFFF), unfocusedContainerColor = Color(0x0DFFFFFF), cursorColor = Color(0xFF00F2FF), focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                shape = RoundedCornerShape(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            IconButton(onClick = onMicClick, modifier = Modifier.size(48.dp).clip(CircleShape).background(if(isListening) Color(0xFFE24B4A) else Color(0x1AFFFFFF))) {
                Icon(if(isListening) Icons.Default.GraphicEq else Icons.Default.Mic, null, tint = Color.White)
            }
            if (text.isNotBlank()) {
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onSend, modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0xFF4285F4))) {
                    Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun TypingIndicator() {
    Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(3) { i ->
            val trans = rememberInfiniteTransition()
            val dy by trans.animateFloat(0f, -8f, infiniteRepeatable(tween(400, delayMillis = i * 100), RepeatMode.Reverse))
            Box(modifier = Modifier.size(6.dp).graphicsLayer { translationY = dy }.clip(CircleShape).background(Color(0xFF4285F4)))
        }
    }
}

fun handleAIAction(action: AIAction, context: android.content.Context, viewModel: AIAssistantViewModel, navController: androidx.navigation.NavController? = null) {
    when(action.type) {
        ActionType.VIEW_ROUTE_RISK -> {
            navController?.navigate("route_risk")
        }
        ActionType.SUGGEST_ROUTE, ActionType.OPEN_MAP -> {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=accident+prone+zone+avoidance"))
            context.startActivity(intent)
        }
        ActionType.NAVIGATE -> {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=hospital"))
            context.startActivity(intent)
        }
        ActionType.CALL -> {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:911"))
            context.startActivity(intent)
        }
        ActionType.SOS -> {
            // Trigger SOS flow - this should ideally call existing SOS logic
            Log.d("AI_ACTION", "SOS Triggered from AI")
        }
        else -> {}
    }
}

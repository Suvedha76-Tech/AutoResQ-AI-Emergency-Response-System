package com.roadsos.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.roadsos.app.viewmodel.RiskLevel
import com.roadsos.app.viewmodel.RouteRiskViewModel
import com.roadsos.app.viewmodel.RouteOption
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

@Composable
fun AiRouteRiskScreen(onBack: () -> Unit) {
    val viewModel: RouteRiskViewModel = viewModel()
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    
    // Theme colors
    val neonCyan = Color(0xFF00F2FF)
    val neonRed = Color(0xFFFF003C)
    val glassBg = Color(0xCC0D0D1A)
    val darkBg = Color(0xFF020205)

    Surface(modifier = Modifier.fillMaxSize(), color = darkBg) {
        Box(modifier = Modifier.fillMaxSize()) {
            // HUD Background
            HUDGridLayer()

            Column(modifier = Modifier.fillMaxSize()) {
                // PREMIUM HEADER
                SafePathHeader(onBack, glassBg, neonCyan)

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 140.dp)
                ) {
                    // INTELLIGENT SEARCH
                    item {
                        SafePathSearch(
                            query = uiState.destination,
                            suggestions = uiState.suggestions,
                            onQueryChange = { viewModel.onSearchTextChange(it) },
                            onSelect = { viewModel.selectDestination(it) },
                            glassBg = glassBg,
                            neonCyan = neonCyan
                        )
                    }

                    // LIVE MAP WIDGET
                    item {
                        RouteMapCard(
                            points = uiState.routeOptions.find { it.id == uiState.selectedRouteId }?.points ?: emptyList(),
                            dest = uiState.destinationPoint,
                            isAnalyzing = uiState.isAnalyzing,
                            glassBg = glassBg,
                            neonCyan = neonCyan
                        )
                    }

                    // ROUTE SELECTOR
                    if (uiState.routeOptions.isNotEmpty()) {
                        item {
                            RouteOptionSelector(
                                options = uiState.routeOptions,
                                selectedId = uiState.selectedRouteId,
                                onSelect = { viewModel.selectRoute(it) },
                                neonCyan = neonCyan,
                                neonRed = neonRed
                            )
                        }
                    }

                    // AI INTELLIGENCE DASHBOARD
                    item {
                        RiskAnalysisDashboard(
                            score = uiState.safetyScore,
                            level = uiState.riskLevel,
                            alerts = uiState.alerts,
                            glassBg = glassBg,
                            neonCyan = neonCyan
                        )
                    }
                }
            }

            // FLOATING ACTION PANEL
            Box(modifier = Modifier.align(Alignment.BottomCenter)) {
                ActionControlPanel(
                    onStart = {
                        val uri = Uri.parse("google.navigation:q=${uiState.destination}")
                        val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps") }
                        context.startActivity(intent)
                    },
                    onShare = { viewModel.shareLocation() },
                    onSOS = { viewModel.triggerSOS() },
                    neonCyan = neonCyan,
                    neonRed = neonRed,
                    glassBg = glassBg
                )
            }
        }
    }
}

@Composable
fun SafePathHeader(onBack: () -> Unit, glassBg: Color, neonCyan: Color) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(16.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(glassBg)
            .border(0.5.dp, Color.White.copy(0.1f), RoundedCornerShape(24.dp)),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp).background(Color.White.copy(0.05f), CircleShape)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text("SAFEPATH AI", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text("Real-Time Route Risk Intelligence", color = neonCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.weight(1f))
            Icon(Icons.Default.GraphicEq, null, tint = neonCyan, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun SafePathSearch(
    query: String,
    suggestions: List<String>,
    onQueryChange: (String) -> Unit,
    onSelect: (String) -> Unit,
    glassBg: Color,
    neonCyan: Color
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = glassBg),
            border = BorderStroke(1.dp, Color.White.copy(0.1f))
        ) {
            Row(modifier = Modifier.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = neonCyan, modifier = Modifier.padding(start = 12.dp))
                TextField(
                    value = query,
                    onValueChange = onQueryChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Where are you heading?", color = Color.Gray, fontSize = 14.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )
                IconButton(onClick = { /* Voice input trigger */ }) {
                    Icon(Icons.Default.Mic, null, tint = neonCyan)
                }
            }
        }

        if (suggestions.isNotEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = glassBg.copy(0.95f))
            ) {
                Column {
                    suggestions.forEach { suggestion ->
                        Text(
                            text = suggestion,
                            color = Color.White,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(suggestion) }
                                .padding(16.dp),
                            fontSize = 13.sp
                        )
                        HorizontalDivider(color = Color.White.copy(0.05f))
                    }
                }
            }
        }
    }
}

@Composable
fun RouteMapCard(
    points: List<GeoPoint>,
    dest: GeoPoint?,
    isAnalyzing: Boolean,
    glassBg: Color,
    neonCyan: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .height(260.dp),
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, neonCyan.copy(0.3f))
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AndroidView(
                factory = { ctx ->
                    Configuration.getInstance().load(ctx, ctx.getSharedPreferences("osm", Context.MODE_PRIVATE))
                    MapView(ctx).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(14.0)
                        
                        // Dark mode matrix
                        val inverseMatrix = floatArrayOf(
                            -1.0f, 0.0f, 0.0f, 0.0f, 255.0f,
                            0.0f, -1.0f, 0.0f, 0.0f, 255.0f,
                            0.0f, 0.0f, -1.0f, 0.0f, 255.0f,
                            0.0f, 0.0f, 0.0f, 1.0f, 0.0f
                        )
                        overlayManager.tilesOverlay.setColorFilter(android.graphics.ColorMatrixColorFilter(inverseMatrix))
                    }
                },
                update = { map ->
                    map.overlays.clear()
                    
                    if (points.isNotEmpty()) {
                        val line = Polyline().apply {
                            setPoints(points)
                            outlinePaint.color = android.graphics.Color.CYAN
                            outlinePaint.strokeWidth = 10f
                        }
                        map.overlays.add(line)
                        map.controller.animateTo(points[points.size/2])
                    }

                    dest?.let {
                        val marker = Marker(map).apply {
                            position = it
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            title = "Destination"
                        }
                        map.overlays.add(marker)
                    }
                    map.invalidate()
                },
                modifier = Modifier.fillMaxSize()
            )

            if (isAnalyzing) {
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.6f)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = neonCyan)
                        Text("AI SCANNING PATH...", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 12.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun RouteOptionSelector(
    options: List<RouteOption>,
    selectedId: String?,
    onSelect: (String) -> Unit,
    neonCyan: Color,
    neonRed: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        options.forEach { option ->
            val isSelected = option.id == selectedId
            val color = if (option.id == "safest") Color(0xFF00FF9D) else Color(0xFFFF9800)
            
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelect(option.id) },
                shape = RoundedCornerShape(16.dp),
                color = if (isSelected) color.copy(0.15f) else Color.White.copy(0.05f),
                border = BorderStroke(1.dp, if (isSelected) color else Color.Transparent)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(option.name.uppercase(), color = color, fontSize = 9.sp, fontWeight = FontWeight.Black)
                    Text("${option.eta} MIN", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(option.distance, color = Color.White.copy(0.6f), fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun RiskAnalysisDashboard(
    score: Int,
    level: RiskLevel,
    alerts: List<String>,
    glassBg: Color,
    neonCyan: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = glassBg),
        border = BorderStroke(1.dp, Color.White.copy(0.05f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(80.dp)) {
                    CircularProgressIndicator(
                        progress = { score / 100f },
                        modifier = Modifier.fillMaxSize(),
                        color = if (score > 80) Color(0xFF00FF9D) else Color(0xFFFF003C),
                        trackColor = Color.White.copy(0.1f),
                        strokeWidth = 8.dp
                    )
                    Text("$score%", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Spacer(modifier = Modifier.width(20.dp))
                Column {
                    Text("AI SAFETY INDEX", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    Text(level.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Analysis updated 2s ago", color = neonCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            alerts.forEach { alert ->
                Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, tint = neonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(alert, color = Color.White.copy(0.8f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ActionControlPanel(
    onStart: () -> Unit,
    onShare: () -> Unit,
    onSOS: () -> Unit,
    neonCyan: Color,
    neonRed: Color,
    glassBg: Color
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .height(100.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(glassBg)
            .border(1.dp, Color.White.copy(0.1f), RoundedCornerShape(32.dp)),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onStart,
                modifier = Modifier.weight(1f).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Navigation, null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("NAVIGATE", color = Color.Black, fontWeight = FontWeight.Black)
            }

            IconButton(onClick = onShare, modifier = Modifier.size(56.dp).clip(CircleShape).background(Color.White.copy(0.05f))) {
                Icon(Icons.Default.Share, null, tint = Color.White)
            }

            Button(
                onClick = onSOS,
                modifier = Modifier.width(80.dp).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = neonRed),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("SOS", color = Color.White, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun HUDGridLayer() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val step = 120f
        for (x in 0..size.width.toInt() step step.toInt()) {
            drawLine(Color.White.copy(0.03f), start = androidx.compose.ui.geometry.Offset(x.toFloat(), 0f), end = androidx.compose.ui.geometry.Offset(x.toFloat(), size.height))
        }
        for (y in 0..size.height.toInt() step step.toInt()) {
            drawLine(Color.White.copy(0.03f), start = androidx.compose.ui.geometry.Offset(0f, y.toFloat()), end = androidx.compose.ui.geometry.Offset(size.width, y.toFloat()))
        }
    }
}

@Composable
fun RiskLivePulse() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(1000), RepeatMode.Reverse))
    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF00FF9D).copy(alpha = alpha)))
}

// ============================================================
// Theme.kt
// ============================================================
package com.roadsos.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Red = Color(0xFFE24B4A)
val DarkRed = Color(0xFFA32D2D)
val Green = Color(0xFF1D9E75)
val DarkBg = Color(0xFF0A0A12)
val CardBg = Color(0xFF0D0D1A)
val SurfaceBg = Color(0xFF131320)

private val DarkColorScheme = darkColorScheme(
    primary = Red,
    onPrimary = Color.White,
    secondary = Green,
    onSecondary = Color.White,
    background = DarkBg,
    surface = CardBg,
    onBackground = Color.White,
    onSurface = Color.White,
    error = Red,
    surfaceVariant = SurfaceBg,
    onSurfaceVariant = Color(0xAAFFFFFF)
)

@Composable
fun RoadSoSTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),
        content = content
    )
}

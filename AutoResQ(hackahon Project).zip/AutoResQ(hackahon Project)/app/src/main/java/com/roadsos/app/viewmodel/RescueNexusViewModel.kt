package com.roadsos.app.viewmodel

import android.app.Application
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.roadsos.app.data.model.Emergency
import com.roadsos.app.repository.EmergencyRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class RescueNexusViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = EmergencyRepository()
    private val auth = FirebaseAuth.getInstance()
    private var syncJob: Job? = null
    private val handler = Handler(Looper.getMainLooper())

    private val _emergencies = MutableLiveData<List<Emergency>>(emptyList())
    val emergencies: LiveData<List<Emergency>> = _emergencies

    private val _activeCount = MutableLiveData<Int>(0)
    val activeCount: LiveData<Int> = _activeCount

    private val _connectionStatus = MutableLiveData<String>("ONLINE")
    val connectionStatus: LiveData<String> = _connectionStatus

    private var userLocation: Location? = null

    fun setUserLocation(location: Location) {
        userLocation = location
    }

    fun startListening() {
        syncJob?.cancel()
        val currentUser = auth.currentUser ?: return
        
        syncJob = viewModelScope.launch {
            try {
                _connectionStatus.postValue("LIVE SYNC")
                repo.listenToActiveEmergencies().collect { list ->
                    // SELF FILTERING
                    val filtered = list.filter { it.userId != currentUser.uid }
                    
                    _emergencies.postValue(filtered)
                    _activeCount.postValue(filtered.size)
                }
            } catch (e: Exception) {
                Log.e("NexusVM", "Sync error", e)
                _connectionStatus.postValue("RECONNECTING")
                retrySync()
            }
        }
    }

    private fun retrySync() {
        handler.postDelayed({ startListening() }, 3000)
    }

    fun stopListening() {
        syncJob?.cancel()
        syncJob = null
    }

    fun acceptEmergencyHelp(emergency: Emergency, onSuccess: (String) -> Unit) {
        val currentUser = auth.currentUser ?: return
        viewModelScope.launch {
            repo.acceptHelp(
                emergencyId = emergency.emergencyId,
                responderId = currentUser.uid,
                responderName = currentUser.displayName ?: "Responder",
                lat = userLocation?.latitude ?: 0.0,
                lng = userLocation?.longitude ?: 0.0
            )
            onSuccess(emergency.emergencyId)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopListening()
        handler.removeCallbacksAndMessages(null)
    }
}

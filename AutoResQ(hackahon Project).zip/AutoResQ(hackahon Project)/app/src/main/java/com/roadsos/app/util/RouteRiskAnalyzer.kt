package com.roadsos.app.util

import com.roadsos.app.viewmodel.RiskLevel

object RouteRiskAnalyzer {

    data class AnalysisResult(
        val score: Int,
        val level: RiskLevel,
        val alerts: List<String>
    )

    fun analyze(
        speed: Float,
        isNight: Boolean,
        weather: String,
        traffic: String,
        hasSharpTurns: Boolean,
        isInAccidentZone: Boolean
    ): AnalysisResult {
        var score = 100

        val alerts = mutableListOf<String>()

        // Traffic Penalty
        when (traffic.lowercase()) {
            "heavy" -> { score -= 15; alerts.add("Heavy traffic detected ahead") }
            "moderate" -> { score -= 5 }
        }

        // Weather Penalty
        if (weather.lowercase() == "rainy" || weather.lowercase() == "stormy") {
            score -= 15
            alerts.add("Rain risk increased: Drive carefully")
        }

        // Night Penalty
        if (isNight) {
            score -= 20
            alerts.add("Night driving risk: Visibility reduced")
        }

        // Accident Zone Penalty
        if (isInAccidentZone) {
            score -= 30
            alerts.add("High accident probability in this area")
        }

        // Speed Penalty
        if (speed > 80) {
            score -= 15
            alerts.add("Overspeeding detected: High risk")
        }

        // Sharp Turns
        if (hasSharpTurns) {
            score -= 10
            alerts.add("Caution: Sharp turns ahead")
        }

        score = score.coerceIn(0, 100)

        val level = when {
            score >= 85 -> RiskLevel.SAFE
            score >= 70 -> RiskLevel.MODERATE
            score >= 40 -> RiskLevel.HIGH_RISK
            else -> RiskLevel.CRITICAL
        }

        if (score < 75) {
            alerts.add("Safer alternate route available")
        }

        return AnalysisResult(score, level, alerts)
    }
}

package com.roadsos.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.DecelerateInterpolator
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.roadsos.app.R
import com.roadsos.app.data.model.Emergency
import com.roadsos.app.databinding.ItemEmergencyCardBinding // I need to enable viewBinding or use findViewById
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.view.animation.LinearInterpolator
import android.graphics.Color
import com.google.firebase.auth.FirebaseAuth

class EmergencyAdapter(
    private var emergencies: List<Emergency>,
    private val onHelpClick: (Emergency) -> Unit,
    private val onCallClick: (Emergency) -> Unit,
    private val onChatClick: (Emergency) -> Unit,
    private val onNavigateClick: (Emergency) -> Unit
) : RecyclerView.Adapter<EmergencyAdapter.ViewHolder>() {

    private val currentUser = FirebaseAuth.getInstance().currentUser

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val binding = ItemEmergencyCardBinding.bind(view)
        
        fun bind(emergency: Emergency, position: Int) {
            // CRITICAL SELF-FILTER RULE
            if (emergency.userId == currentUser?.uid) {
                itemView.visibility = View.GONE
                itemView.layoutParams = RecyclerView.LayoutParams(0, 0)
                return
            } else {
                itemView.visibility = View.VISIBLE
                itemView.layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            binding.username.text = emergency.username
            binding.address.text = emergency.address
            binding.emergencyTypeChip.text = emergency.emergencyType.uppercase()
            binding.aiRiskChip.text = "AI RISK: ${emergency.aiRiskLevel}"
            binding.respondersCount.text = "${emergency.respondersCount} Responders"
            binding.ambulanceEta.text = "AMB: ${emergency.ambulanceETA.ifEmpty { "N/A" }}"
            binding.batteryNetwork.text = "${emergency.batteryPercent}% | ${emergency.networkStrength}/5"
            
            val secondsAgo = (System.currentTimeMillis() - emergency.lastUpdated.toDate().time) / 1000
            binding.lastUpdated.text = "Last synced: ${secondsAgo}s ago"

            // Status Badge Colors & Text
            val (statusText, statusColor) = when(emergency.status) {
                "AWAITING_RESPONDERS" -> "AWAITING HELP" to "#E24B4A"
                "RESPONDER_ASSIGNED" -> "ASSIGNED" to "#FF9800"
                "HELP_ON_THE_WAY" -> "HELP COMING" to "#00F2FF"
                "RESPONDER_ARRIVED" -> "ARRIVED" to "#4CAF50"
                else -> emergency.status to "#FFFFFF"
            }
            binding.statusBadge.text = statusText
            binding.statusBadge.setTextColor(Color.parseColor(statusColor))

            Glide.with(itemView.context)
                .load(emergency.avatarUrl)
                .placeholder(R.drawable.ic_account)
                .into(binding.avatar)

            binding.verifiedBadge.visibility = if (emergency.isVerified) View.VISIBLE else View.GONE

            // Action Listeners
            binding.btnHelp.setOnClickListener { onHelpClick(emergency) }
            binding.btnCall.setOnClickListener { onCallClick(emergency) }
            binding.btnChat.setOnClickListener { onChatClick(emergency) }
            binding.btnNavigate.setOnClickListener { onNavigateClick(emergency) }

            // Animations
            applyAnimations(binding)
        }
    }

    private fun applyAnimations(binding: ItemEmergencyCardBinding) {
        // I CAN HELP button pulse
        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.05f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.05f)
        ObjectAnimator.ofPropertyValuesHolder(binding.btnHelp, scaleX, scaleY).apply {
            duration = 800
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        // LIVE SYNC text blink
        val blink = AlphaAnimation(1f, 0.2f).apply {
            duration = 800
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        binding.liveSyncText.startAnimation(blink)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_emergency_card, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(emergencies[position], position)
        
        // Card slide-in animation
        holder.itemView.translationX = 600f
        holder.itemView.alpha = 0f
        holder.itemView.animate()
            .translationX(0f)
            .alpha(1f)
            .setDuration(400)
            .setInterpolator(DecelerateInterpolator())
            .setStartDelay(position * 80L)
            .start()
    }

    override fun getItemCount() = emergencies.size

    fun updateData(newList: List<Emergency>) {
        emergencies = newList
        notifyDataSetChanged()
    }
}

package com.roadsos.app.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.roadsos.app.util.RouteRiskAnalyzer
import com.roadsos.app.ui.screens.EmergencyAlertActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.osmdroid.util.GeoPoint
import java.util.*

enum class RiskLevel {
    SAFE, MODERATE, HIGH_RISK, CRITICAL
}

data class RouteOption(
    val id: String,
    val name: String,
    val riskLevel: RiskLevel,
    val eta: Int,
    val distance: String,
    val points: List<GeoPoint> = emptyList(),
    val score: Int = 100
)

data class AdvancedRouteRiskState(
    val safetyScore: Int = 100,
    val riskLevel: RiskLevel = RiskLevel.SAFE,
    val trafficSeverity: String = "Low",
    val weatherCondition: String = "Clear",
    val speed: Float = 0f,
    val alerts: List<String> = emptyList(),
    val isAnalyzing: Boolean = false,
    val destination: String = "",
    val destinationPoint: GeoPoint? = null,
    val signalStrength: Int = 4,
    val fatigueRisk: String = "Low",
    val visibility: String = "High",
    val suggestions: List<String> = emptyList(),
    val routeOptions: List<RouteOption> = emptyList(),
    val selectedRouteId: String? = null
)

class RouteRiskViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(AdvancedRouteRiskState())
    val uiState = _uiState.asStateFlow()

    private val context: Context get() = getApplication()
    private var searchJob: Job? = null
    private val geocoder = Geocoder(context, Locale.getDefault())

    // Mocked Current Location for Route Generation (Coimbatore center)
    private val currentPos = GeoPoint(11.0168, 76.9558)

    fun onSearchTextChange(query: String) {
        _uiState.update { it.copy(destination = query) }
        searchJob?.cancel()
        if (query.length > 2) {
            searchJob = viewModelScope.launch {
                delay(500) // Debounce
                try {
                    val addresses = geocoder.getFromLocationName(query, 5)
                    val results = addresses?.map { it.getAddressLine(0) } ?: emptyList()
                    _uiState.update { it.copy(suggestions = results) }
                } catch (e: Exception) {
                    Log.e("SEARCH", "Geocoding failed", e)
                }
            }
        } else {
            _uiState.update { it.copy(suggestions = emptyList()) }
        }
    }

    fun selectDestination(address: String) {
        _uiState.update { it.copy(destination = address, suggestions = emptyList(), isAnalyzing = true) }
        viewModelScope.launch {
            try {
                val addresses = geocoder.getFromLocationName(address, 1)
                if (!addresses.isNullOrEmpty()) {
                    val target = GeoPoint(addresses[0].latitude, addresses[0].longitude)
                    generateRoutes(target)
                }
            } catch (e: Exception) {
                Log.e("NAV", "Selection failed", e)
                _uiState.update { it.copy(isAnalyzing = false) }
            }
        }
    }

    private fun generateRoutes(target: GeoPoint) {
        viewModelScope.launch {
            delay(1000) // Simulate pathfinding

            val safestRoute = RouteOption(
                id = "safest",
                name = "Safest Route",
                riskLevel = RiskLevel.SAFE,
                eta = 22,
                distance = "8.2 km",
                score = 98,
                points = createBezierRoute(currentPos, target, 0.01)
            )

            val fastestRoute = RouteOption(
                id = "fastest",
                name = "Fastest Route",
                riskLevel = RiskLevel.MODERATE,
                eta = 15,
                distance = "7.5 km",
                score = 72,
                points = createBezierRoute(currentPos, target, -0.005)
            )

            _uiState.update { 
                it.copy(
                    routeOptions = listOf(safestRoute, fastestRoute),
                    selectedRouteId = "safest",
                    destinationPoint = target,
                    isAnalyzing = false,
                    safetyScore = safestRoute.score,
                    riskLevel = safestRoute.riskLevel,
                    alerts = listOf("AI: Safest route detected with optimal light exposure.", "Community: Minimal accident reports on this path.")
                )
            }
        }
    }

    private fun createBezierRoute(start: GeoPoint, end: GeoPoint, curve: Double): List<GeoPoint> {
        val points = mutableListOf<GeoPoint>()
        val midLat = (start.latitude + end.latitude) / 2 + curve
        val midLng = (start.longitude + end.longitude) / 2 + curve
        
        for (i in 0..20) {
            val t = i / 20.0
            val lat = (1 - t) * (1 - t) * start.latitude + 2 * (1 - t) * t * midLat + t * t * end.latitude
            val lng = (1 - t) * (1 - t) * start.longitude + 2 * (1 - t) * t * midLng + t * t * end.longitude
            points.add(GeoPoint(lat, lng))
        }
        return points
    }

    fun selectRoute(id: String) {
        val route = _uiState.value.routeOptions.find { it.id == id } ?: return
        _uiState.update { 
            it.copy(
                selectedRouteId = id,
                safetyScore = route.score,
                riskLevel = route.riskLevel,
                alerts = if (id == "fastest") listOf("Warning: Route passes through a high-traffic zone.", "Caution: Low visibility detected at intersection.")
                         else listOf("AI: Safest route detected.", "Community: Minimal accident reports on this path.")
            )
        }
    }

    fun triggerSOS() {
        val intent = Intent(context, EmergencyAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("isDemoMode", false)
        }
        context.startActivity(intent)
    }

    fun shareLocation() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "I'm using SafePath AI. My route safety score is ${_uiState.value.safetyScore}%. ETA: 15m")
        }
        val chooser = Intent.createChooser(shareIntent, "Share SafePath")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun refreshAnalysis() {
        _uiState.update { it.copy(isAnalyzing = true) }
        viewModelScope.launch {
            delay(800)
            _uiState.update { it.copy(isAnalyzing = false) }
        }
    }
}

package com.roadsos.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.animation.core.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.ui.text.style.TextAlign

@Composable
fun EmergencyEvidenceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("VIDEO") }
    
    val root = context.getExternalFilesDir(null)
    val videoDir = File(root, "Evidence/videos")
    val audioDir = File(root, "Evidence/audio")
    val imageDir = File(root, "Evidence/images")
    
    // Refresh files dynamically
    var files by remember { mutableStateOf(emptyList<File>()) }
    
    LaunchedEffect(selectedTab) {
        val dir = when (selectedTab) {
            "VIDEO" -> videoDir
            "AUDIO" -> audioDir
            else -> imageDir
        }
        files = dir.listFiles()?.toList()?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    var selectedFile by remember { mutableStateOf<File?>(null) }
    var showDeleteDialog by remember { mutableStateOf<File?>(null) }

    Scaffold(
        containerColor = Color(0xFF0A0A0F),
        topBar = {
            Column {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                    Text("Evidence Vault", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    if (selectedFile != null) {
                        IconButton(onClick = { selectedFile = null }) {
                            Icon(Icons.Default.Close, null, tint = Color.White)
                        }
                    }
                }
                if (selectedFile == null) {
                    TabRow(
                        selectedTabIndex = when (selectedTab) {
                            "VIDEO" -> 0
                            "AUDIO" -> 1
                            else -> 2
                        },
                        containerColor = Color.Transparent,
                        contentColor = Color(0xFFE53935),
                        divider = {}
                    ) {
                        Tab(
                            selected = selectedTab == "VIDEO",
                            onClick = { selectedTab = "VIDEO" },
                            text = { Text("VIDEOS", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTab == "AUDIO",
                            onClick = { selectedTab = "AUDIO" },
                            text = { Text("AUDIO", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTab == "IMAGE",
                            onClick = { selectedTab = "IMAGE" },
                            text = { Text("IMAGES", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (selectedFile != null) {
                EvidencePlayer(
                    file = selectedFile!!,
                    onClose = { selectedFile = null }
                )
            } else if (files.isEmpty()) {
                EmptyEvidenceState()
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(files) { file ->
                        EvidenceVaultItem(
                            file = file,
                            type = selectedTab,
                            onClick = { selectedFile = file },
                            onDelete = { showDeleteDialog = file },
                            onShare = { shareFile(context, file) }
                        )
                    }
                }
            }
        }
    }

    if (showDeleteDialog != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            containerColor = Color(0xFF161620),
            title = { Text("Delete Evidence?", color = Color.White) },
            text = { Text("This recording will be permanently removed from your device.", color = Color.Gray) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog?.delete()
                        showDeleteDialog = null
                        // Refresh list
                        val dir = when (selectedTab) {
                            "VIDEO" -> videoDir
                            "AUDIO" -> audioDir
                            else -> imageDir
                        }
                        files = dir.listFiles()?.toList()?.sortedByDescending { it.lastModified() } ?: emptyList()
                    }
                ) {
                    Text("DELETE", color = Color(0xFFE53935), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("CANCEL", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun EvidenceVaultItem(
    file: File,
    type: String,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    val date = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date(file.lastModified()))
    val size = String.format("%.2f MB", file.length() / (1024.0 * 1024.0))
    val icon = when (type) {
        "VIDEO" -> Icons.Default.Videocam
        "AUDIO" -> Icons.Default.Mic
        else -> Icons.Default.Image
    }

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161620)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(44.dp).background(Color(0xFFE53935).copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = Color(0xFFE53935), modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(file.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("$date • $size", color = Color.Gray, fontSize = 11.sp)
                }
                IconButton(onClick = onShare) {
                    Icon(Icons.Default.Share, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                }
            }
            
            // Session Details Subtitle
            if (file.name.contains("RNX_SESSION")) {
                val sessionId = file.name.substringBefore("_video").substringBefore("_audio").substringBefore("_snapshot")
                if (sessionId.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier.background(Color.White.copy(0.05f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("Session: $sessionId", color = Color(0xFFE53935), fontSize = 9.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun EvidencePlayer(file: File, onClose: () -> Unit) {
    val context = LocalContext.current
    val isVideo = file.name.endsWith(".mp4")
    val isAudio = file.name.endsWith(".aac") || file.name.endsWith(".m4a")
    val isImage = file.name.endsWith(".jpg") || file.name.endsWith(".png") || file.name.endsWith(".jpeg")

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (isVideo || isAudio) {
            val exoPlayer = remember {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                    prepare()
                    playWhenReady = true
                }
            }

            DisposableEffect(Unit) {
                onDispose { exoPlayer.release() }
            }

            if (isVideo) {
                Box(modifier = Modifier.fillMaxSize()) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = exoPlayer
                                useController = true
                                setBackgroundColor(0x00000000)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.align(Alignment.TopStart).padding(16.dp).background(Color.Black.copy(0.3f), CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                }
            } else {
                // Audio Player UI
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier.size(120.dp).background(Color(0xFFE53935).copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Mic, null, tint = Color(0xFFE53935), modifier = Modifier.size(64.dp))
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(file.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(48.dp))
                    
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = exoPlayer
                                controllerHideOnTouch = false
                                controllerShowTimeoutMs = 0
                                // Media3 hide buttons via styling or specific methods
                                // If these don't work, we'll use a simpler view
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(100.dp)
                    )
                }
            }
        } else if (isImage) {
            var scale by remember { mutableFloatStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }
            val state = rememberTransformableState { zoomChange, offsetChange, _ ->
                scale *= zoomChange
                offset += offsetChange
            }

            AsyncImage(
                model = file,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale.coerceIn(1f, 5f),
                        scaleY = scale.coerceIn(1f, 5f),
                        translationX = offset.x,
                        translationY = offset.y
                    )
                    .transformable(state = state),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
fun EmptyEvidenceState() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "shield")
        val alpha by infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 0.7f,
            animationSpec = infiniteRepeatable(tween(2000), RepeatMode.Reverse),
            label = "alpha"
        )

        Icon(
            Icons.Default.Security,
            null,
            tint = Color(0xFFE53935).copy(alpha = alpha),
            modifier = Modifier.size(100.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text("No Emergency Evidence Found", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Recorded evidence will appear here securely.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

fun shareFile(context: Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = if (file.name.endsWith(".mp4")) "video/*" else if (file.name.endsWith(".aac")) "audio/*" else "image/*"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share Evidence"))
}

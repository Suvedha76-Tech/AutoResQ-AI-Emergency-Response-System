package com.roadsos.app.service

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.*
import android.util.Log
import androidx.camera.core.*
import androidx.camera.core.ConcurrentCamera.SingleCameraConfig
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.*
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.roadsos.app.MainActivity
import com.roadsos.app.R
import com.roadsos.app.data.local.UserPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class EvidenceShieldService : LifecycleService() {

    private lateinit var cameraExecutor: ExecutorService
    private var videoCaptureFront: VideoCapture<Recorder>? = null
    private var videoCaptureBack: VideoCapture<Recorder>? = null
    private var previewFront: Preview? = null
    private var previewBack: Preview? = null
    private var imageCaptureFront: ImageCapture? = null
    
    private var recordingFront: Recording? = null
    private var recordingBack: Recording? = null
    private var audioRecorder: MediaRecorder? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var locationCallback: LocationCallback? = null
    
    private val db = FirebaseFirestore.getInstance()
    private lateinit var userPrefs: UserPreferences
    private var sessionId: String? = null
    private var startTime: Long = 0
    private val handler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null

    private var isDualVideoSupported = false

    companion object {
        const val CHANNEL_ID = "evidence_shield_channel"
        const val NOTIFICATION_ID = 101
        const val ACTION_STOP = "com.roadsos.app.STOP_EVIDENCE_SHIELD"

        // UI State
        var isConcurrentSupported = false
            private set

        // Shared SurfaceProviders for UI Previews
        var frontSurfaceProvider: Preview.SurfaceProvider? = null
            set(value) {
                field = value
                instance?.previewFront?.setSurfaceProvider(value)
            }
        var backSurfaceProvider: Preview.SurfaceProvider? = null
            set(value) {
                field = value
                instance?.previewBack?.setSurfaceProvider(value)
            }
        
        private var instance: EvidenceShieldService? = null
        fun isRunning() = instance != null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        cameraExecutor = Executors.newFixedThreadPool(2)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        userPrefs = UserPreferences(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startTime = System.currentTimeMillis()
        sessionId = "RNX_SESSION_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}"
        
        startForeground(NOTIFICATION_ID, buildNotification("00:00"))
        
        lifecycleScope.launch {
            createEmergencySession()
            startAllRecordings()
            startGpsTracking()
            startTimer()
        }

        return START_STICKY
    }

    private fun startTimer() {
        timerRunnable = object : Runnable {
            override fun run() {
                val elapsed = (System.currentTimeMillis() - startTime) / 1000
                val timeStr = String.format(Locale.getDefault(), "%02d:%02d", elapsed / 60, elapsed % 60)
                updateNotification(timeStr)
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(timerRunnable!!)
    }

    private suspend fun createEmergencySession() {
        val phone = try { userPrefs.userPhone.first() } catch (e: Exception) { "unknown" }
        val sessionData = hashMapOf(
            "sessionId" to sessionId,
            "userId" to phone,
            "status" to "ACTIVE",
            "timestamp" to Timestamp.now(),
            "shieldMode" to "ACTIVE",
            "videoRecording" to true,
            "audioRecording" to true,
            "latitude" to 0.0,
            "longitude" to 0.0
        )
        
        sessionId?.let {
            db.collection("emergency_sessions").document(it).set(sessionData)
                .addOnSuccessListener { Log.d("EvidenceShield", "Firestore session created") }
        }
    }

    private fun startAllRecordings() {
        ensureDirectories()
        startVideoRecording()
        startAudioRecording()
    }

    private fun ensureDirectories() {
        val root = getExternalFilesDir(null)
        File(root, "Evidence/videos").mkdirs()
        File(root, "Evidence/audio").mkdirs()
        File(root, "Evidence/images").mkdirs()
    }

    private fun startVideoRecording() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            
            // Check for concurrent camera support
            val concurrentCameraInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                cameraProvider.availableConcurrentCameraInfos
            } else emptyList()
            
            isConcurrentSupported = concurrentCameraInfos.isNotEmpty()
            isDualVideoSupported = isConcurrentSupported
            Log.d("EvidenceShield", "Concurrent Camera Supported: $isDualVideoSupported")

            cameraProvider.unbindAll()

            if (isDualVideoSupported) {
                try {
                    // CONCURRENT MODE: Bind both Front and Back together
                    val backSelector = CameraSelector.DEFAULT_BACK_CAMERA
                    val recorderBack = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.LOWEST)).build()
                    videoCaptureBack = VideoCapture.withOutput(recorderBack)
                    previewBack = Preview.Builder().build()
                    backSurfaceProvider?.let { previewBack?.setSurfaceProvider(it) }

                    val frontSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                    val recorderFront = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.LOWEST)).build()
                    videoCaptureFront = VideoCapture.withOutput(recorderFront)
                    previewFront = Preview.Builder().build()
                    frontSurfaceProvider?.let { previewFront?.setSurfaceProvider(it) }

                    val backConfig = SingleCameraConfig(
                        backSelector,
                        UseCaseGroup.Builder().addUseCase(videoCaptureBack!!).addUseCase(previewBack!!).build(),
                        this
                    )
                    val frontConfig = SingleCameraConfig(
                        frontSelector,
                        UseCaseGroup.Builder().addUseCase(videoCaptureFront!!).addUseCase(previewFront!!).build(),
                        this
                    )

                    cameraProvider.bindToLifecycle(listOf(backConfig, frontConfig))
                    
                    startVideoCapture(videoCaptureBack!!, "back") { recordingBack = it }
                    startVideoCapture(videoCaptureFront!!, "front") { recordingFront = it }
                    
                    Log.d("EvidenceShield", "Concurrent cameras bound successfully")
                } catch (e: Exception) {
                    Log.e("EvidenceShield", "Concurrent binding failed, falling back", e)
                    isDualVideoSupported = false
                    startSingleCamera(cameraProvider)
                }
            } else {
                startSingleCamera(cameraProvider)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun startSingleCamera(cameraProvider: ProcessCameraProvider) {
        // PRIMARY: BACK CAMERA
        try {
            val backSelector = CameraSelector.DEFAULT_BACK_CAMERA
            val recorderBack = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.LOWEST))
                .build()
            videoCaptureBack = VideoCapture.withOutput(recorderBack)
            previewBack = Preview.Builder().build()
            backSurfaceProvider?.let { previewBack?.setSurfaceProvider(it) }
            
            cameraProvider.bindToLifecycle(this, backSelector, videoCaptureBack, previewBack)
            startVideoCapture(videoCaptureBack!!, "back") { recordingBack = it }
            
            Log.d("EvidenceShield", "Single camera (Back) bound")
            
            // If snapshots were needed, they would likely conflict here on non-concurrent devices.
            // So we don't bind front camera at all if isDualVideoSupported is false.
        } catch (e: Exception) {
            Log.e("EvidenceShield", "Back camera error", e)
        }
    }

    private fun startPeriodicSnapshots() {
        lifecycleScope.launch {
            while (isActive && instance != null) {
                try {
                    captureSnapshot()
                } catch (e: Exception) {}
                delay(5000) // Snapshot every 5 seconds
            }
        }
    }

    private fun captureSnapshot() {
        val imageCapture = imageCaptureFront ?: return
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val name = "${sessionId ?: "RNX"}_snapshot_front_$timestamp.jpg"
        val file = File(getExternalFilesDir(null), "Evidence/images/$name")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                Log.d("EvidenceShield", "Front snapshot saved")
            }
            override fun onError(exception: ImageCaptureException) {
                Log.e("EvidenceShield", "Snapshot failed", exception)
            }
        })
    }

    private fun startVideoCapture(videoCapture: VideoCapture<Recorder>, tag: String, onStarted: (Recording) -> Unit) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val name = "${sessionId ?: "RNX"}_video_${tag}_$timestamp.mp4"
        val videoFile = File(getExternalFilesDir(null), "Evidence/videos/$name")
        
        val outputOptions = FileOutputOptions.Builder(videoFile).build()
        
        val recording = videoCapture.output
            .prepareRecording(this, outputOptions)
            .start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    if (event.hasError()) Log.e("EvidenceShield", "Video $tag error: ${event.error}")
                }
            }
        onStarted(recording)
    }

    private fun startAudioRecording() {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val name = "${sessionId ?: "RNX"}_audio_$timestamp.aac"
        val audioFile = File(getExternalFilesDir(null), "Evidence/audio/$name")
        
        audioRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(this)
        } else {
            @Suppress("DEPRECATION") MediaRecorder()
        }.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(audioFile.absolutePath)
            try {
                prepare()
                start()
            } catch (e: Exception) {
                Log.e("EvidenceShield", "Audio record failed", e)
            }
        }
    }

    private fun startGpsTracking() {
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000).build()
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                sessionId?.let {
                    db.collection("emergency_sessions").document(it)
                        .update("latitude", loc.latitude, "longitude", loc.longitude)
                }
            }
        }
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback!!, Looper.getMainLooper())
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Evidence Shield", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(timer: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, EvidenceShieldService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🛡 Evidence Shield Active")
            .setContentText("Recording Evidence • $timer")
            .setSmallIcon(R.drawable.ic_warning)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_warning, "STOP", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(timer: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(timer))
    }

    override fun onDestroy() {
        instance = null
        frontSurfaceProvider = null
        backSurfaceProvider = null

        timerRunnable?.let { handler.removeCallbacks(it) }
        recordingFront?.stop()
        recordingBack?.stop()
        try {
            audioRecorder?.stop()
            audioRecorder?.release()
        } catch (e: Exception) {}
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        
        sessionId?.let {
            db.collection("emergency_sessions").document(it).update("status", "SECURED")
        }
        
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}

package com.roadsos.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MapActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val lat = intent.getStringExtra("lat")?.toDouble()
        val lng = intent.getStringExtra("lng")?.toDouble()

        if (lat != null && lng != null) {

            val uri = Uri.parse("google.navigation:q=$lat,$lng")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")

            startActivity(intent)
        }

        finish()
    }
}
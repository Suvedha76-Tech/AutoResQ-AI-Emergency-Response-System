package com.roadsos.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.roadsos.app.data.model.Emergency
import com.roadsos.app.ui.adapter.EmergencyAdapter
import com.roadsos.app.viewmodel.MainViewModel
import com.roadsos.app.viewmodel.RescueNexusViewModel

@Composable
fun RescueNexusScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToHospitals: () -> Unit = {}
) {
    val nexusViewModel: RescueNexusViewModel = viewModel()
    val emergencies by nexusViewModel.emergencies.observeAsState(emptyList())
    val activeCount by nexusViewModel.activeCount.observeAsState(0)
    val connectionStatus by nexusViewModel.connectionStatus.observeAsState("ONLINE")
    
    val context = LocalContext.current
    val neonRed = Color(0xFFFF003C)
    val neonCyan = Color(0xFF00F2FF)
    val darkBg = Color(0xFF020205)
    
    var currentTab by remember { mutableStateOf("FEED") }

    // Fix 1: Firestore listener lifecycle
    DisposableEffect(Unit) {
        nexusViewModel.startListening()
        onDispose {
            nexusViewModel.stopListening()
        }
    }

    Scaffold(
        containerColor = darkBg,
        topBar = {
            // Fix 2: Header Layout (Fixed at top)
            RescueNexusHeader(
                activeCount = activeCount,
                connectionStatus = connectionStatus,
                onBack = onBack,
                neonRed = neonRed
            )
        },
        bottomBar = {
            // Fix 7: Rescue Nexus Tabs (Fixed at bottom)
            RescueNexusTabs(
                selectedTab = currentTab,
                onTabSelected = { currentTab = it },
                neonGreen = Color(0xFF00FF9D)
            )
        }
    ) { padding ->
        // Fix 8: Layout Structure Order - Scrolling content between Header and Tabs
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Fix 3: Radar MUST ALWAYS BE VISIBLE
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(darkBg),
                contentAlignment = Alignment.Center
            ) {
                RadarView(hasEmergencies = activeCount > 0, neonRed = neonRed, neonCyan = neonCyan)
            }

            // Fix 4: AI Threat Intelligence Card
            AIThreatIntelligenceCard(neonCyan = neonCyan)

            Spacer(modifier = Modifier.height(24.dp))

            // Fix 5: Community Emergency Feed Section
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "COMMUNITY EMERGENCY FEED",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                when (currentTab) {
                    "FEED" -> {
                        if (emergencies.isEmpty()) {
                            EmptyFeedState()
                        } else {
                            // Using AndroidView for RecyclerView
                            AndroidView(
                                factory = { ctx ->
                                    RecyclerView(ctx).apply {
                                        layoutManager = LinearLayoutManager(ctx)
                                        isNestedScrollingEnabled = false // Allow parent scroll
                                        adapter = EmergencyAdapter(
                                            emergencies = emergencies,
                                            onHelpClick = { e -> 
                                                nexusViewModel.acceptEmergencyHelp(e) { 
                                                    Toast.makeText(ctx, "Rescue Accepted!", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            onCallClick = {},
                                            onChatClick = {},
                                            onNavigateClick = {}
                                        )
                                    }
                                },
                                update = { recyclerView ->
                                    (recyclerView.adapter as? EmergencyAdapter)?.updateData(emergencies)
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(max = 2000.dp)
                            )
                        }
                    }
                    "AI" -> AIIntelligenceView()
                    "MAP" -> Box(Modifier.fillMaxWidth().height(200.dp)) { Text("Map View", color = Color.White, modifier = Modifier.align(Alignment.Center)) }
                    "MEDICAL" -> Box(Modifier.fillMaxWidth().height(200.dp)) { Text("First Aid View", color = Color.White, modifier = Modifier.align(Alignment.Center)) }
                    "HISTORY" -> Box(Modifier.fillMaxWidth().height(200.dp)) { Text("History View", color = Color.White, modifier = Modifier.align(Alignment.Center)) }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun RescueNexusHeader(
    activeCount: Int,
    connectionStatus: String,
    onBack: () -> Unit,
    neonRed: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D1A)),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, Color.White.copy(0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Top Left: Back arrow
                IconButton(onClick = onBack, modifier = Modifier.background(Color.White.copy(0.05f), CircleShape)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                
                // Top Right: Online Status
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isOnline = connectionStatus != "RECONNECTING"
                    val dotColor = if (isOnline) Color.Green else Color.Yellow
                    
                    if (!isOnline) {
                        val infiniteTransition = rememberInfiniteTransition(label = "blink")
                        val alpha by infiniteTransition.animateFloat(
                            initialValue = 1f, targetValue = 0.2f,
                            animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse), label = ""
                        )
                        Box(modifier = Modifier.size(8.dp).graphicsLayer { this.alpha = alpha }.background(dotColor, CircleShape))
                    } else {
                        Box(modifier = Modifier.size(8.dp).background(dotColor, CircleShape))
                    }
                    
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOnline) "ONLINE" else "RECONNECTING",
                        color = dotColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text("RESCUE NEXUS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            
            // Active count
            Text(
                text = "$activeCount ACTIVE COMMUNITY EMERGENCIES",
                color = neonRed,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            
            // Sync status
            Text(
                text = if (connectionStatus == "LIVE SYNC") "LIVE SYNC" else "RECONNECTING",
                color = if (connectionStatus == "LIVE SYNC") Color.Green else Color.Yellow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun RadarView(hasEmergencies: Boolean, neonRed: Color, neonCyan: Color) {
    val color = if (hasEmergencies) neonRed else neonCyan.copy(alpha = 0.5f)
    val duration = if (hasEmergencies) 1200 else 2400
    
    Box(contentAlignment = Alignment.Center) {
        // Dark circular background
        Box(modifier = Modifier.size(240.dp).background(Color.Black.copy(0.3f), CircleShape).border(1.dp, color.copy(0.1f), CircleShape))
        
        val infiniteTransition = rememberInfiniteTransition(label = "radar")
        
        repeat(3) { index ->
            val scale by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1.2f,
                animationSpec = infiniteRepeatable(
                    animation = tween(duration, delayMillis = index * 600, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ), label = ""
            )
            val alpha by infiniteTransition.animateFloat(
                initialValue = 0.6f,
                targetValue = 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(duration, delayMillis = index * 600, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ), label = ""
            )
            
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .border(2.dp, color, CircleShape)
            )
        }
        
        // Central pulse
        Box(modifier = Modifier.size(20.dp).background(color, CircleShape))
    }
}

@Composable
fun AIThreatIntelligenceCard(neonCyan: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D1A)),
        border = BorderStroke(1.dp, neonCyan.copy(0.2f))
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = neonCyan,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text("AI THREAT INTELLIGENCE", color = neonCyan, fontSize = 12.sp, fontWeight = FontWeight.Black)
                Text("Passive community scanning… AI Sector Monitoring Active", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun EmptyFeedState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.ArrowUpward, null, tint = Color.White.copy(0.3f), modifier = Modifier.size(48.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text("No active emergencies nearby", color = Color.White.copy(0.5f), fontSize = 14.sp)
    }
}

@Composable
fun RescueNexusTabs(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    neonGreen: Color
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .height(64.dp),
        color = Color(0xFF0D0D1A),
        shape = RoundedCornerShape(32.dp),
        border = BorderStroke(1.dp, Color.White.copy(0.05f))
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                "FEED" to Icons.Default.RssFeed,
                "AI" to Icons.Default.AutoAwesome,
                "MAP" to Icons.Default.LocationOn,
                "MEDICAL" to Icons.Default.LocalHospital,
                "HISTORY" to Icons.Default.History
            )
            
            tabs.forEach { (tab, icon) ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color.DarkGray else Color.Transparent)
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            icon, 
                            null, 
                            tint = if (isSelected) neonGreen else Color.White.copy(0.4f),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = when(tab) {
                                "FEED" -> "Feed"
                                "AI" -> "AI Scan"
                                "MAP" -> "Map"
                                "MEDICAL" -> "First Aid"
                                "HISTORY" -> "History"
                                else -> tab
                            },
                            color = if (isSelected) neonGreen else Color.White.copy(0.4f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AIIntelligenceView() {
    Column(modifier = Modifier.padding(16.dp)) {
        AIThreatIntelligenceCard(neonCyan = Color(0xFF00F2FF))
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D1A)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color.White.copy(0.05f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("DETAILED SECTOR ANALYSIS", color = Color(0xFF00F2FF), fontSize = 10.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Scanning radius: 10km\nActive Nodes: 124\nThreat Level: Low\nResponse Capacity: Optimal", color = Color.White.copy(0.7f), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Text("AI Sector Monitoring Active. No critical threats detected.", color = Color.Green.copy(0.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

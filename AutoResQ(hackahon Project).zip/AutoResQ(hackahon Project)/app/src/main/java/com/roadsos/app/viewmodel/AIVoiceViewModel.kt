package com.roadsos.app.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import com.roadsos.app.service.VoiceDetectionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class VoiceMode {
    NORMAL, HIGH_SENSITIVITY, WHISPER_MODE, NIGHT_SAFETY
}

data class VoiceState(
    val isEnabled: Boolean = false,
    val isListening: Boolean = false,
    val mode: VoiceMode = VoiceMode.NORMAL,
    val detectedPhrase: String? = null,
    val rmsdB: Float = 0f
)

class AIVoiceViewModel(application: Application) : AndroidViewModel(application) {
    private val context: Context get() = getApplication()
    
    private val _voiceState = MutableStateFlow(VoiceState())
    val voiceState = _voiceState.asStateFlow()

    companion object {
        private val _instanceState = MutableStateFlow(VoiceState())
        val instanceState = _instanceState.asStateFlow()

        private val _dangerDetected = MutableSharedFlow<Unit>()
        val dangerDetected = _dangerDetected.asSharedFlow()
        
        fun updateState(updater: (VoiceState) -> VoiceState) {
            _instanceState.update(updater)
        }

        fun onDangerDetected() {
            _instanceState.update { it.copy(detectedPhrase = "Danger Detected") }
            CoroutineScope(Dispatchers.Main).launch {
                _dangerDetected.emit(Unit)
            }
        }
    }

    init {
        // Sync with static state
        _voiceState.value = _instanceState.value
    }

    fun toggleProtection() {
        val newState = !_voiceState.value.isEnabled
        _voiceState.update { it.copy(isEnabled = newState) }
        _instanceState.update { it.copy(isEnabled = newState) }
        
        if (newState) {
            startVoiceService()
        } else {
            stopVoiceService()
        }
    }

    fun setMode(mode: VoiceMode) {
        _voiceState.update { it.copy(mode = mode) }
        _instanceState.update { it.copy(mode = mode) }
        // If service is running, it might need to know the mode change
        if (_voiceState.value.isEnabled) {
            startVoiceService() // Restart with new mode
        }
    }

    private fun startVoiceService() {
        val intent = Intent(context, VoiceDetectionService::class.java).apply {
            putExtra("mode", _voiceState.value.mode.name)
        }
        context.startForegroundService(intent)
        Log.d("VoiceViewModel", "Starting Voice Service")
    }

    private fun stopVoiceService() {
        val intent = Intent(context, VoiceDetectionService::class.java)
        context.stopService(intent)
        Log.d("VoiceViewModel", "Stopping Voice Service")
        _voiceState.update { it.copy(isListening = false, rmsdB = 0f) }
        _instanceState.update { it.copy(isListening = false, rmsdB = 0f) }
    }
}

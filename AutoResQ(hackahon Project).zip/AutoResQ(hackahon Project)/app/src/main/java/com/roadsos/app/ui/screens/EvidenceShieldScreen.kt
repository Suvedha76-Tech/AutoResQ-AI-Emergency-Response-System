package com.roadsos.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.roadsos.app.service.EvidenceShieldService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*
import kotlin.random.Random
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle

@Composable
fun EvidenceShieldScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var isRecording by remember { mutableStateOf(EvidenceShieldService.isRunning()) }
    var recordingTime by remember { mutableLongStateOf(0L) }
    var statusText by remember { mutableStateOf(if (isRecording) "🔴 Recording all sensors..." else "Tap to activate all sensors") }
    
    val permissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION
    )
    
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) {
            // All granted
        }
    }

    LaunchedEffect(Unit) {
        if (permissions.any { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }) {
            launcher.launch(permissions)
        }
    }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            statusText = "🔴 Recording all sensors..."
            while (isRecording) {
                delay(1000)
                recordingTime++
            }
        } else if (recordingTime > 0) {
            statusText = "✅ Evidence secured to cloud"
        } else {
            statusText = "Tap to activate all sensors"
        }
    }

    Scaffold(
        containerColor = Color(0xFF0A0A0F),
        topBar = {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Evidence Shield", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Text(statusText, color = if (isRecording) Color(0xFFE53935) else Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(start = 56.dp))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // CENTER RECORD BUTTON
            RecordButton(isRecording) {
                if (isRecording) {
                    isRecording = false
                    context.stopService(Intent(context, EvidenceShieldService::class.java))
                } else {
                    isRecording = true
                    recordingTime = 0L
                    ContextCompat.startForegroundService(context, Intent(context, EvidenceShieldService::class.java))
                }
            }

            // LIVE TIMER
            if (isRecording) {
                Text(
                    text = "⏱ ${formatTime(recordingTime)}",
                    color = Color(0xFFE57373),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
            } else {
                Spacer(modifier = Modifier.height(32.dp))
            }

            // SENSOR STATUS CHIPS ROW
            SensorChipsRow(isRecording)

            // DUAL CAMERA PREVIEW GRID
            DualCameraGrid(isRecording)

            // MICROPHONE WAVEFORM VISUALIZER
            MicrophoneVisualizer(isRecording)

            // CLOUD UPLOAD STATUS CARD
            CloudUploadCard(isRecording)

            // PHONE DESTROY PROTECTION BANNER
            PhoneDestroyBanner()

            // STOP BUTTON
            if (isRecording) {
                Button(
                    onClick = { 
                        isRecording = false 
                        context.stopService(Intent(context, EvidenceShieldService::class.java))
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A0505)),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, Color(0xFFE53935))
                ) {
                    Text("⏹ STOP & SECURE EVIDENCE", color = Color(0xFFE53935), fontSize = 15.sp, fontWeight = FontWeight.W800)
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun RecordButton(isRecording: Boolean, onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
        label = "scale"
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
        label = "alpha"
    )

    val shadowIntensity by infiniteTransition.animateFloat(
        initialValue = 5f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "shadow"
    )

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
        if (isRecording) {
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .background(Color(0xFFE53935).copy(alpha = 0.4f), CircleShape)
            )
        }

        Surface(
            onClick = onClick,
            modifier = Modifier
                .size(110.dp)
                .graphicsLayer {
                    if (isRecording) {
                        shadowElevation = shadowIntensity.dp.toPx()
                        spotShadowColor = Color(0xFFE53935)
                    }
                },
            shape = CircleShape,
            color = Color.Transparent
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(listOf(Color(0xFFF44336), Color(0xFFB71C1C))),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                        null,
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        if (isRecording) "RECORDING" else "RECORD ALL",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun SensorChipsRow(isRecording: Boolean) {
    val sensors = listOf(
        SensorInfo("FRONT CAM", Color(0xFFE53935)),
        SensorInfo("BACK CAM", Color(0xFFE53935)),
        SensorInfo("MIC", Color(0xFFAB47BC)),
        SensorInfo("GPS", Color(0xFF4CAF50)),
        SensorInfo("CLOUD", Color(0xFF2196F3))
    )
    
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
        items(sensors) { sensor ->
            SensorChip(sensor, isRecording)
        }
    }
}

data class SensorInfo(val label: String, val activeColor: Color)

@Composable
fun SensorChip(sensor: SensorInfo, isRecording: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "blink")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            tween(if (sensor.label == "MIC") 700 else 1000),
            RepeatMode.Reverse
        ),
        label = "blink"
    )

    val isActive = isRecording
    val bgColor = if (isActive) sensor.activeColor.copy(alpha = 0.15f) else Color(0xFF1A1A1A)
    val borderColor = if (isActive) sensor.activeColor.copy(alpha = 0.3f) else Color(0xFF333333)
    val contentColor = if (isActive) sensor.activeColor.copy(alpha = 0.8f) else Color(0xFF555555)

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .graphicsLayer {
                        if (isActive && (sensor.label.contains("CAM") || sensor.label == "MIC")) {
                            this.alpha = alpha
                        }
                    }
                    .background(contentColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(sensor.label, color = contentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DualCameraGrid(isRecording: Boolean) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CameraCard(Modifier.weight(1f), "FRONT", isRecording, isFront = true)
        CameraCard(Modifier.weight(1f), "BACK", isRecording, isFront = false)
    }
}

@Composable
fun CameraCard(modifier: Modifier, label: String, isRecording: Boolean, isFront: Boolean) {
    val context = LocalContext.current
    
    Card(
        modifier = modifier.aspectRatio(4f/3f),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F18)),
        border = if (isRecording) BorderStroke(1.5.dp, Color(0xFFE53935).copy(alpha = 0.5f)) else null
    ) {
        Box(modifier = Modifier.fillMaxSize().graphicsLayer { alpha = if (isRecording) 1f else 0.3f }) {
            
            if (isRecording) {
                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            if (isFront) {
                                EvidenceShieldService.frontSurfaceProvider = this.surfaceProvider
                            } else {
                                EvidenceShieldService.backSurfaceProvider = this.surfaceProvider
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                        Icon(if (isFront) Icons.Default.Person else Icons.Default.Camera, null, tint = Color.Gray, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        val isSupported = if (isFront) EvidenceShieldService.isConcurrentSupported else true
                        
                        Text(
                            text = if (!isSupported) "Hardware does not support dual camera" else "TAP RECORD",
                            color = Color.Gray, 
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // SCAN LINE
            if (isRecording) {
                val infiniteTransition = rememberInfiniteTransition(label = "scan")
                val scanOffset by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart),
                    label = "scan"
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .graphicsLayer { translationY = scanOffset * 150.dp.toPx() } // Approximate height
                        .background(Color(0xFFE53935).copy(alpha = 0.5f))
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(label, color = Color.White, fontSize = 10.sp)
            }

            if (isRecording) {
                val blinkAlpha by rememberInfiniteTransition(label = "rec_blink").animateFloat(
                    1f, 0f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = ""
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(8.dp)
                        .graphicsLayer { alpha = blinkAlpha }
                        .background(Color.Red, CircleShape)
                )
                
                Text(
                    text = if (isFront) "FRONT CAM ACTIVE" else "BACK CAM ACTIVE",
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(8.dp).background(Color.Red.copy(0.5f), RoundedCornerShape(4.dp)).padding(2.dp)
                )
            }
        }
    }
}

@Composable
fun MicrophoneVisualizer(isRecording: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (isRecording) 1f else 0.3f },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F18)),
        border = BorderStroke(1.dp, Color(0xFF1A1A2E))
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.height(30.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(18) { index ->
                    val infiniteTransition = rememberInfiniteTransition(label = "wave")
                    val height by infiniteTransition.animateFloat(
                        initialValue = 4f,
                        targetValue = 28f,
                        animationSpec = infiniteRepeatable(
                            tween(500 + (index * 50), easing = LinearOutSlowInEasing),
                            RepeatMode.Reverse
                        ),
                        label = "height"
                    )
                    
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height((if (isRecording) height else 4f).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color(0xFFAB47BC))
                    )
                }
            }
            Text("MIC ACTIVE", color = Color(0xFFCE93D8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CloudUploadCard(isRecording: Boolean) {
    var speed by remember { mutableIntStateOf(0) }
    
    LaunchedEffect(isRecording) {
        if (isRecording) {
            while (isRecording) {
                speed = Random.nextInt(180, 321)
                delay(1000)
            }
        } else {
            speed = 0
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (isRecording) 1f else 0.3f },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
        border = BorderStroke(1.dp, Color(0xFF0D47A1))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("☁ Secure Cloud Upload", color = Color(0xFF64B5F6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("$speed KB/s", color = Color(0xFF555555), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(12.dp))
            
            val infiniteTransition = rememberInfiniteTransition(label = "progress")
            val progress by infiniteTransition.animateFloat(
                initialValue = 0.1f,
                targetValue = 0.95f,
                animationSpec = infiniteRepeatable(tween(3000), RepeatMode.Restart),
                label = "progress"
            )

            Box(modifier = Modifier.fillMaxWidth().height(4.dp).background(Color(0xFF0D1F3A), CircleShape)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(if (isRecording) progress else 0f)
                        .fillMaxHeight()
                        .background(Color(0xFF1565C0), CircleShape)
                )
            }
        }
    }
}

@Composable
fun PhoneDestroyBanner() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0A0A)),
        border = BorderStroke(1.dp, Color(0xFF4A1A1A))
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Text("⚠️", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color(0xFFEF5350))) {
                        append("Phone Destroy Protection: ")
                    }
                    withStyle(SpanStyle(color = Color(0xFFE57373))) {
                        append("Even if your device is damaged or wiped, all recordings are instantly backed up to encrypted cloud storage. Evidence is safe no matter what.")
                    }
                },
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
    }
}

fun formatTime(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}

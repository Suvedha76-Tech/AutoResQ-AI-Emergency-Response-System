package com.roadsos.app.repository

import android.content.Context
import android.location.Geocoder
import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.roadsos.app.data.model.SOSAlert
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.*

class SOSRepository(private val context: Context) {

    private val db = FirebaseFirestore.getInstance()
    private val sosRef = db.collection("sos_alerts")

    suspend fun triggerSOS(
        userId: String,
        username: String,
        lat: Double,
        lng: Double,
        batteryLevel: Int,
        emergencyType: String = "Collision"
    ): String? {
        val address = getAddressFromCoords(lat, lng)
        val data = hashMapOf(
            "userId" to userId,
            "username" to username,
            "profileImage" to "",
            "latitude" to lat,
            "longitude" to lng,
            "address" to address,
            "emergencyType" to emergencyType,
            "batteryLevel" to batteryLevel,
            "networkStrength" to (3..5).random(),
            "riskLevel" to "HIGH",
            "timestamp" to Timestamp.now(),
            "status" to "ACTIVE",
            "helperCount" to 0,
            "responderETA" to "4 min",
            "active" to true,
            "deviceId" to android.os.Build.MODEL
        )

        return try {
            val doc = sosRef.add(data).await()
            doc.id
        } catch (e: Exception) {
            Log.e("SOS_REPO", "Trigger SOS failed", e)
            null
        }
    }

    fun listenToSOSAlerts(): Flow<List<SOSAlert>> = callbackFlow {
        val listener = sosRef
            .whereEqualTo("active", true)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("SOS_REPO", "Listen error", error)
                    return@addSnapshotListener
                }

                val alerts = snapshot?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    SOSAlert(
                        id = doc.id,
                        userId = data["userId"] as? String ?: "",
                        username = data["username"] as? String ?: "Anonymous",
                        profileImage = data["profileImage"] as? String ?: "",
                        latitude = (data["latitude"] as? Double) ?: 0.0,
                        longitude = (data["longitude"] as? Double) ?: 0.0,
                        address = data["address"] as? String ?: "",
                        emergencyType = data["emergencyType"] as? String ?: "",
                        batteryLevel = (data["batteryLevel"] as? Long)?.toInt() ?: 0,
                        networkStrength = (data["networkStrength"] as? Long)?.toInt() ?: 4,
                        riskLevel = data["riskLevel"] as? String ?: "HIGH",
                        timestamp = data["timestamp"] as? Timestamp ?: Timestamp.now(),
                        status = data["status"] as? String ?: "ACTIVE",
                        helperCount = (data["helperCount"] as? Long)?.toInt() ?: 0,
                        responderETA = data["responderETA"] as? String ?: "",
                        active = data["active"] as? Boolean ?: true,
                        deviceId = data["deviceId"] as? String ?: ""
                    )
                } ?: emptyList()

                trySend(alerts)
            }
        awaitClose { listener.remove() }
    }

    suspend fun resolveSOS(sosId: String) {
        try {
            sosRef.document(sosId).update(
                mapOf("active" to false, "status" to "RESOLVED")
            ).await()
        } catch (e: Exception) {
            Log.e("SOS_REPO", "Resolve failed", e)
        }
    }

    suspend fun addHelperToSOS(sosId: String) {
        try {
            val doc = sosRef.document(sosId).get().await()
            val currentCount = doc.getLong("helperCount") ?: 0
            sosRef.document(sosId).update("helperCount", currentCount + 1).await()
        } catch (e: Exception) {
            Log.e("SOS_REPO", "Add helper failed", e)
        }
    }

    private fun getAddressFromCoords(lat: Double, lng: Double): String {
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                addresses[0].getAddressLine(0)
            } else {
                "Unknown Location"
            }
        } catch (e: Exception) {
            "Location: $lat, $lng"
        }
    }
}

package com.roadsos.app.ui.screens

import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roadsos.app.data.model.EmergencyStatus
import com.roadsos.app.data.model.Helper
import com.roadsos.app.ui.theme.RoadSoSTheme
import com.roadsos.app.viewmodel.EmergencyViewModel
import kotlinx.coroutines.*

class EmergencyAlertActivity : ComponentActivity() {

    private val viewModel: EmergencyViewModel by viewModels()
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        val lat = intent.getDoubleExtra("latitude", 13.0827)
        val lng = intent.getDoubleExtra("longitude", 80.2707)
        val isDemo = intent.getBooleanExtra("isDemoMode", false)

        viewModel.init(lat, lng, isDemo)
        startAlarm()
        startVibration()

        setContent {
            RoadSoSTheme {
                EmergencyAlertScreen(
                    viewModel = viewModel,
                    onSafe = {
                        stopAlarm()
                        viewModel.markAsSafe()
                        finish()
                    },
                    onCallHelp = {
                        stopAlarm()
                        viewModel.triggerSOS()
                    },
                    onAutoSOS = {
                        stopAlarm()
                        viewModel.triggerSOS()
                    }
                )
            }
        }
    }

    private fun startAlarm() {
        try {
            val alarmUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@EmergencyAlertActivity, alarmUri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            try {
                val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                mediaPlayer = MediaPlayer.create(this, notificationUri).apply {
                    isLooping = true
                    start()
                }
            } catch (e2: Exception) {}
        }
    }

    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 400, 200, 400, 200, 800)
        vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
    }

    private fun stopAlarm() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        vibrator?.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAlarm()
    }
}

@Composable
fun EmergencyAlertScreen(
    viewModel: EmergencyViewModel,
    onSafe: () -> Unit,
    onCallHelp: () -> Unit,
    onAutoSOS: () -> Unit
) {
    val state by viewModel.emergencyState.collectAsStateWithLifecycle()
    val helpers by viewModel.helpers.collectAsStateWithLifecycle()
    val currentEmergency by viewModel.currentEmergency.collectAsStateWithLifecycle()
    
    var secondsLeft by remember { mutableIntStateOf(30) }
    
    LaunchedEffect(state.sosSent) {
        if (!state.sosSent) {
            while (secondsLeft > 0 && !state.sosSent) {
                delay(1000L)
                secondsLeft--
            }
            if (secondsLeft == 0 && !state.sosSent) {
                onAutoSOS()
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0000)),
        contentAlignment = Alignment.Center
    ) {
        if (state.sosSent) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x22E24B4A), Color(0xFF0D0000))
                        )
                    )
            )
        }

        LazyColumn(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Top
        ) {
            item { Spacer(modifier = Modifier.height(40.dp)) }
            
            item {
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .scale(scale)
                            .background(Color(0x15E24B4A), CircleShape)
                    )
                    Text("🚨", fontSize = 80.sp)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            item {
                Text(
                    text = if (state.sosSent) "RESCUE MODE ACTIVE" else "ACCIDENT DETECTED",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                
                state.statusMessage?.let { msg ->
                    Text(
                        text = msg,
                        color = Color(0xFFE24B4A),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(top = 8.dp),
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(32.dp))
            }

            if (!state.sosSent) {
                item {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = { secondsLeft / 30f },
                            modifier = Modifier.size(100.dp),
                            color = Color(0xFFE24B4A),
                            trackColor = Color(0x22FFFFFF),
                            strokeWidth = 8.dp
                        )
                        Text(
                            text = "$secondsLeft",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE24B4A)
                        )
                    }
                    Spacer(modifier = Modifier.height(40.dp))
                    Button(
                        onClick = onSafe,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D9E75)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("✓  I AM SAFE", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = onCallHelp,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        border = BorderStroke(2.dp, Color(0xFFE24B4A)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("📞  TRIGGER SOS NOW", fontWeight = FontWeight.Bold, color = Color(0xFFE24B4A), fontSize = 16.sp)
                    }
                }
            } else {
                item {
                    RescueTimeline(
                        status = state.statusMessage,
                        helpersCount = helpers.size,
                        priority = currentEmergency?.priority ?: "NORMAL",
                        isResolved = currentEmergency?.status == "RESOLVED"
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                }

                val primaryHelperId = currentEmergency?.primaryHelperId
                val primaryHelper = helpers.find { it.userId == primaryHelperId }
                
                if (primaryHelper != null) {
                    item {
                        Text("PRIMARY RESPONDER", color = Color(0x88FFFFFF), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
                        HelperCard(helper = primaryHelper, isPrimary = true)
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                val backupHelpers = helpers.filter { it.userId != primaryHelperId }
                if (backupHelpers.isNotEmpty()) {
                    item {
                        Text("BACKUP HELPERS (${backupHelpers.size})", color = Color(0x88FFFFFF), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
                    }
                    items(backupHelpers) { helper ->
                        HelperCard(helper = helper, isPrimary = false)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                if (helpers.isEmpty() && currentEmergency?.status != "RESOLVED") {
                    item {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFFE24B4A), modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Broadcasting to all users in ${currentEmergency?.radius?.toInt() ?: 5}km radius...", color = Color(0x88FFFFFF), fontSize = 12.sp)
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(40.dp))
                    Button(
                        onClick = onSafe,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (currentEmergency?.status == "RESOLVED") Color.Gray else Color(0xFF1D9E75)),
                        shape = RoundedCornerShape(14.dp),
                        enabled = currentEmergency?.status != "RESOLVED"
                    ) {
                        Text(if (currentEmergency?.status == "RESOLVED") "RESCUE COMPLETED" else "I AM NOW SAFE / RESOLVED", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
fun RescueTimeline(status: String?, helpersCount: Int, priority: String, isResolved: Boolean) {
    val steps = listOf(
        "SOS Broadcasted" to true,
        "Nearby Users Alerted" to (status != "Analyzing..."),
        "$helpersCount Helpers Responded" to (helpersCount > 0),
        "Primary Helper Assigned" to (helpersCount > 0),
        "Rescue Completed" to isResolved
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0x0AFFFFFF)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(0.5.dp, Color(0x1AFFFFFF))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📋 LIVE RESCUE TIMELINE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                if (priority == "HIGH") {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFE24B4A)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("ESCALATED", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            steps.forEach { (text, completed) ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(if (completed) Color(0xFF1D9E75) else Color(0x22FFFFFF), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text, color = if (completed) Color.White else Color(0x44FFFFFF), fontSize = 13.sp, fontWeight = if (completed) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun HelperCard(helper: Helper, isPrimary: Boolean) {
    // Dynamic ETA calculation: Assume 30km/h -> 2 min per km
    val distKm = try { helper.distance.split(" ")[0].toDouble() } catch (e: Exception) { 0.0 }
    val etaMin = (distKm * 2).toInt().coerceAtLeast(1)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (isPrimary) Color(0x151D9E75) else Color(0x0AFFFFFF)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (isPrimary) Color(0xFF1D9E75) else Color(0x1AFFFFFF))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(if (isPrimary) Color(0xFF1D9E75) else Color(0x22FFFFFF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isPrimary) "⭐" else "🏃", fontSize = 20.sp)
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(helper.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0x88FFFFFF), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${helper.distance} away", color = Color(0x88FFFFFF), fontSize = 12.sp)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                StatusChip(text = "ETA $etaMin MIN", color = if (isPrimary) Color(0xFF1D9E75) else Color(0xFFE24B4A))
                Spacer(modifier = Modifier.height(4.dp))
                Text("Live Tracking", color = Color(0xFF1D9E75), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StatusChip(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.2f))
            .border(0.5.dp, color, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

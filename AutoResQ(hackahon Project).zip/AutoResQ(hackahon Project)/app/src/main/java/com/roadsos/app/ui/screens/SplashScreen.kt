package com.roadsos.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.roadsos.app.R
import com.roadsos.app.data.local.UserPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlin.math.sin

@Composable
fun SplashScreen(navController: NavController) {
    val context = LocalContext.current
    val userPrefs = UserPreferences(context)
    
    var startAnimation by remember { mutableStateOf(false) }

    // Infinite Animations
    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    
    // Logo floating effect
    val logoBounce by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float"
    )

    // Ambient Glow pulsing
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    // Entrance Animations
    val contentAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(1500),
        label = "alpha"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
        delay(4000)
        val registered = userPrefs.isUserRegistered.first()
        if (registered) {
            navController.navigate("home") {
                popUpTo("splash") { inclusive = true }
            }
        } else {
            navController.navigate("register") {
                popUpTo("splash") { inclusive = true }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A0A1A),
                        Color(0xFF020205)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // 1. Background elements (Road perspective)
        RoadPerspectiveLayer(contentAlpha)

        // 2. Center Content (Logo + Glow)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.offset(y = (-40).dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                // Ambient Red Glow
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .graphicsLayer(alpha = glowAlpha)
                        .background(Color(0xFFE24B4A).copy(alpha = 0.5f), CircleShape)
                        .blur(60.dp)
                )

                // Logo with float animation
                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "AutoResQ Logo",
                    modifier = Modifier
                        .size(160.dp)
                        .offset(y = logoBounce.dp)
                        .alpha(contentAlpha)
                        .clip(RoundedCornerShape(32.dp))
                )
            }

            Spacer(modifier = Modifier.height(60.dp))

            // Text Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.alpha(contentAlpha)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Welcome to",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Light,
                        letterSpacing = 4.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AUTORESQ",
                        color = Color(0xFFE24B4A),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )
                }
                
                // Small horizontal red line
                Box(
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .width(40.dp)
                        .height(1.5.dp)
                        .background(Color(0xFFE24B4A).copy(alpha = 0.8f))
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Smart AI-powered emergency\nprotection for safer journeys",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 1.sp
                )
            }
        }

        // 3. Loading indicator
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 60.dp)
                .alpha(contentAlpha)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = Color(0xFFE24B4A).copy(alpha = 0.7f),
                strokeWidth = 2.dp
            )
        }
    }
}

@Composable
fun RoadPerspectiveLayer(alpha: Float) {
    Box(modifier = Modifier.fillMaxSize().alpha(alpha)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            
            // Draw curved road perspective
            val roadPath = Path().apply {
                moveTo(w * 0.45f, h * 0.7f) // Top narrow end
                quadraticBezierTo(
                    w * 0.5f, h * 0.85f,
                    w * 0.2f, h // Bottom left
                )
                lineTo(w * 0.8f, h) // Bottom right
                quadraticBezierTo(
                    w * 0.6f, h * 0.85f,
                    w * 0.55f, h * 0.7f // Back to top right
                )
                close()
            }

            drawPath(
                path = roadPath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color(0xFF1A1A1A).copy(alpha = 0.4f), Color(0xFF0D0D0D)),
                    startY = h * 0.7f,
                    endY = h
                )
            )

            // Side glowing dots (Markers)
            val leftPoints = listOf(
                Offset(w * 0.44f, h * 0.72f),
                Offset(w * 0.41f, h * 0.78f),
                Offset(w * 0.35f, h * 0.86f),
                Offset(w * 0.25f, h * 0.95f)
            )
            
            val rightPoints = listOf(
                Offset(w * 0.56f, h * 0.72f),
                Offset(w * 0.59f, h * 0.78f),
                Offset(w * 0.65f, h * 0.86f),
                Offset(w * 0.75f, h * 0.95f)
            )

            leftPoints.forEachIndexed { i, offset ->
                drawCircle(Color(0xFFE24B4A).copy(alpha = 0.8f), radius = (2 + i).dp.toPx(), center = offset)
                drawCircle(Color(0xFFE24B4A).copy(alpha = 0.3f), radius = (6 + i).dp.toPx(), center = offset) // Glow
            }
            
            rightPoints.forEachIndexed { i, offset ->
                drawCircle(Color(0xFFE24B4A).copy(alpha = 0.8f), radius = (2 + i).dp.toPx(), center = offset)
                drawCircle(Color(0xFFE24B4A).copy(alpha = 0.3f), radius = (6 + i).dp.toPx(), center = offset) // Glow
            }

            // Road center line
            val centerPath = Path().apply {
                moveTo(w * 0.5f, h * 0.72f)
                quadraticBezierTo(w * 0.53f, h * 0.88f, w * 0.45f, h)
            }
            drawPath(
                path = centerPath,
                color = Color.White.copy(alpha = 0.15f),
                style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 20f), 0f))
            )
        }

        // Location Pin Pin on Road
        Box(modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = null,
                tint = Color(0xFFE24B4A),
                modifier = Modifier
                    .size(32.dp)
                    .align(Alignment.BottomCenter)
                    .offset(x = 50.dp, y = (-180).dp)
                    .graphicsLayer {
                        shadowElevation = 8.dp.toPx()
                    }
            )
            // Pin Glow
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .align(Alignment.BottomCenter)
                    .offset(x = 50.dp, y = (-175).dp)
                    .background(Color(0xFFE24B4A).copy(alpha = 0.2f), CircleShape)
                    .blur(10.dp)
            )
        }
    }
}

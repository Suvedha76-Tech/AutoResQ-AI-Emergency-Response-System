// ============================================================
// RoadSoSFCMService.kt  — Firebase Cloud Messaging
// ============================================================
package com.roadsos.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.roadsos.app.MainActivity

class RoadSoSFCMService : FirebaseMessagingService() {

    companion object {
        const val CHANNEL_ID = "roadsos_alerts"
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Save token to Firestore for this user
        // In production: update user document with new token
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: "🚨 RoadSoS Alert"
        val body = message.notification?.body ?: "Accident nearby! Can you help?"
        showNotification(title, body, message.data)
    }

    private fun showNotification(title: String, body: String, data: Map<String, String>) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID, "Emergency Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
            enableLights(true)
        }
        manager.createNotificationChannel(channel)

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            data["emergencyId"]?.let { putExtra("emergencyId", it) }
            data["latitude"]?.let { putExtra("latitude", it.toDoubleOrNull() ?: 0.0) }
            data["longitude"]?.let { putExtra("longitude", it.toDoubleOrNull() ?: 0.0) }
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 400, 200, 400))
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}

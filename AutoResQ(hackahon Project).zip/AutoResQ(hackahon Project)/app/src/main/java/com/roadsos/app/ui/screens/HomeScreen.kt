package com.roadsos.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.roadsos.app.data.model.*
import com.roadsos.app.viewmodel.AIVoiceViewModel
import com.roadsos.app.viewmodel.MainViewModel
import com.roadsos.app.viewmodel.RouteRiskViewModel
import com.roadsos.app.viewmodel.VoiceMode

@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: MainViewModel,
    onNavigateToNearby: () -> Unit,
    onNavigateToShield: () -> Unit,
    onTriggerDemo: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val incomingAlert by viewModel.incomingAlert.collectAsStateWithLifecycle()
    val myLoc by viewModel.currentLocation.collectAsStateWithLifecycle()
    val nearbyHospitals by viewModel.nearbyHospitals.collectAsStateWithLifecycle()
    val aiVoiceViewModel: AIVoiceViewModel = viewModel()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0A0A12)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFE24B4A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🚨", fontSize = 20.sp)
                            }
                            Column {
                                Text("ROAD", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                                Text("SOS", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFFE24B4A))
                            }
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        IconButton(onClick = { navController.navigate("profile") }) {
                            Icon(Icons.Default.AccountCircle, contentDescription = "Profile", tint = Color.White)
                        }
                    }
                }

                // 🔔 INCOMING ALERT SECTION
                if (incomingAlert != null) {
                    item {
                        IncomingAlertCard(
                            emergency = incomingAlert!!,
                            myLocation = myLoc,
                            onHelp = { viewModel.onICanHelp(incomingAlert!!) },
                            onDismiss = { viewModel.dismissAlert() }
                        )
                    }
                }

                // Status card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0x0AFFFFFF)),
                        border = BorderStroke(0.5.dp, Color(0x1AFFFFFF))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.Sensors, contentDescription = null, tint = Color(0xFF1D9E75), modifier = Modifier.size(24.dp))
                            Column {
                                Text(uiState.statusMessage, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium)
                                Text("Community Response Active", fontSize = 11.sp, color = Color(0x88FFFFFF))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Nearby Hospitals Section
                val nearestHospital = nearbyHospitals.firstOrNull()
                if (nearestHospital != null) {
                    item {
                        NearbyHospitalCard(
                            hospital = nearestHospital,
                            onClick = { navController.navigate("hospitals") }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                // 🎤 AI VOICE PROTECTION CARD
                item {
                    AIVoiceProtectionCard(viewModel = aiVoiceViewModel)
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Quick Actions
                item {
                    Text("QUICK ACTIONS", fontSize = 10.sp, color = Color(0x66FFFFFF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                    
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            QuickActionCard(
                                icon = Icons.Default.Security,
                                title = "Evidence Shield",
                                subtitle = "Record & protect instantly",
                                modifier = Modifier.weight(1f),
                                accentColor = Color(0xFFE53935),
                                isShield = true,
                                onClick = onNavigateToShield
                            )
                            QuickActionCard(
                                icon = Icons.Default.People, 
                                title = "Nearby", 
                                subtitle = "Community help", 
                                modifier = Modifier.weight(1f), 
                                onClick = onNavigateToNearby
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            QuickActionCard(
                                icon = Icons.Default.History, 
                                title = "Logs", 
                                subtitle = "View recordings", 
                                modifier = Modifier.weight(1f), 
                                accentColor = Color(0xFF2196F3),
                                onClick = { navController.navigate("evidence_list") }
                            )
                            QuickActionCard(
                                icon = Icons.Default.Shield,
                                title = "Route Risk AI",
                                subtitle = "Smart route analysis",
                                modifier = Modifier.weight(1f),
                                accentColor = Color(0xFF00F2FF),
                                onClick = { navController.navigate("route_risk") }
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            QuickActionCard(
                                icon = Icons.Default.LocalHospital, 
                                title = "Hospitals", 
                                subtitle = "Find nearest ER", 
                                modifier = Modifier.weight(1f), 
                                accentColor = Color(0xFF378ADD), 
                                onClick = { navController.navigate("hospitals") }
                            )
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // SOS Buttons Section
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (uiState.sosTriggered) {
                            Button(
                                onClick = { viewModel.resolveEmergency() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(58.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D9E75)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("✅  I AM NOW SAFE / RESOLVED", fontSize = 15.sp, fontWeight = FontWeight.Black)
                            }
                        } else {
                            Button(
                                onClick = {
                                    viewModel.triggerEvidenceShield("MANUAL_SOS")
                                    viewModel.triggerRealtimeCommunitySOS()
                                    navController.navigate("live_sos")
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(58.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE24B4A)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("🆘  SEND SOS NOW", fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            }
                        }

                        OutlinedButton(
                            onClick = onTriggerDemo,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(58.dp),
                            border = BorderStroke(2.dp, Color(0xFFE24B4A)),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE24B4A))
                        ) {
                            Text("🤖  DEMO: AUTO ACCIDENT", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
fun EvidenceShieldCard(
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "shield_pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "glow"
    )

    Card(
        modifier = modifier
            .height(110.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F101F)),
        border = BorderStroke(1.dp, Color(0xFFE24B4A).copy(alpha = glowAlpha))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    Icons.Default.Security, 
                    contentDescription = null, 
                    tint = Color(0xFFE24B4A), 
                    modifier = Modifier.size(28.dp)
                )
                
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    StatusBadge("REC", Color(0xFFE24B4A))
                    StatusBadge("GPS", Color(0xFF4CAF50))
                    StatusBadge("CLOUD", Color(0xFF2196F3))
                }
            }
            
            Column {
                Text(
                    text = "Evidence Shield", 
                    fontSize = 14.sp, 
                    color = Color.White, 
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Record & protect instantly", 
                    fontSize = 10.sp, 
                    color = Color(0x99FFFFFF),
                    lineHeight = 12.sp
                )
            }
        }
    }
}

@Composable
fun StatusBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.5.dp, color.copy(alpha = 0.3f))
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 7.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun IncomingAlertCard(
    emergency: Emergency,
    myLocation: Pair<Double, Double>?,
    onHelp: () -> Unit,
    onDismiss: () -> Unit
) {
    val distStr = if (myLocation != null) {
        val repo = com.roadsos.app.repository.EmergencyRepository()
        val dist = repo.calculateDistance(myLocation.first, myLocation.second, emergency.latitude, emergency.longitude)
        repo.formatDistance(dist)
    } else "..."

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x15E24B4A)),
        border = BorderStroke(1.dp, Color(0xFFE24B4A)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🆘", fontSize = 24.sp)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("URGENT: ${emergency.emergencyType.uppercase()}", color = Color(0xFFE24B4A), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    Text("${emergency.username} is $distStr away", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onHelp,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE24B4A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("I CAN HELP", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun NearbyHospitalCard(
    hospital: Hospital,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D1A)),
        border = BorderStroke(0.5.dp, Color(0x30FFFFFF))
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0x15E24B4A), Color.Transparent),
                            radius = 400f
                        )
                    )
            )

            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x15E24B4A))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.LocalHospital,
                            contentDescription = null,
                            tint = Color(0xFFE24B4A),
                            modifier = Modifier.size(24.dp).graphicsLayer(scaleX = scale, scaleY = scale)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Nearby Emergency Hospital", fontSize = 11.sp, color = Color(0x99FFFFFF), fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(hospital.name, fontSize = 17.sp, color = Color.White, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x201D9E75))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("ER READY", color = Color(0xFF1D9E75), fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0x66FFFFFF), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${hospital.distance} • ${hospital.eta} away", fontSize = 13.sp, color = Color(0xCCFFFFFF), fontWeight = FontWeight.Medium)
                }
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        val gmmIntentUri = Uri.parse("google.navigation:q=${hospital.latitude},${hospital.longitude}")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                        mapIntent.setPackage("com.google.android.apps.maps")
                        context.startActivity(mapIntent)
                    },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE24B4A)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("NAVIGATE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun QuickActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    accentColor: Color = Color(0xFFE24B4A),
    isShield: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(110.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161620)),
        border = BorderStroke(0.5.dp, Color(0x1AFFFFFF))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    icon, 
                    contentDescription = title, 
                    tint = accentColor, 
                    modifier = Modifier.size(24.dp)
                )
                if (isShield) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        StatusBadge("REC", Color(0xFFE24B4A))
                        StatusBadge("GPS", Color(0xFF4CAF50))
                        StatusBadge("CLOUD", Color(0xFF2196F3))
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title, 
                fontSize = 13.sp, 
                color = Color.White, 
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = subtitle, 
                fontSize = 10.sp, 
                color = Color(0x99FFFFFF), 
                maxLines = 2,
                lineHeight = 12.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun AIVoiceProtectionCard(
    viewModel: AIVoiceViewModel
) {
    val state by viewModel.voiceState.collectAsStateWithLifecycle()
    val infiniteTransition = rememberInfiniteTransition(label = "voice_glow")

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    val micScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state.isEnabled) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    val isActive = state.isEnabled
    val isEmergency = state.detectedPhrase != null

    val cardBgColor = Color(0xFF0F101F)
    val accentRed = Color(0xFFFF3B30)
    val accentCyan = Color(0xFF00F2FF)
    val accentBlue = Color(0xFF0066FF)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        border = BorderStroke(
            width = 1.dp,
            brush = if (isActive) {
                Brush.sweepGradient(
                    colors = if (isEmergency) listOf(accentRed, accentRed.copy(0.3f), accentRed)
                    else listOf(accentCyan, accentBlue, accentCyan)
                )
            } else {
                SolidColor(Color(0x22FFFFFF))
            }
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "AI VOICE PROTECTION",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = if (isActive) "SYSTEM ACTIVE & LISTENING" else "PROTECTION OFFLINE",
                        color = if (isActive) accentCyan.copy(alpha = 0.8f) else Color(0x44FFFFFF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Switch(
                    checked = isActive,
                    onCheckedChange = { viewModel.toggleProtection() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = if (isEmergency) accentRed else accentBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF080914)),
                contentAlignment = Alignment.Center
            ) {
                if (isActive) {
                    VoiceWaveform(
                        isListening = state.isListening, 
                        rms = state.rmsdB
                    )
                } else {
                    Icon(Icons.Default.MicOff, null, tint = Color(0x22FFFFFF), modifier = Modifier.size(24.dp))
                }
            }

            if (isActive && isEmergency) {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().background(accentRed.copy(0.1f), RoundedCornerShape(8.dp)).padding(8.dp)
                ) {
                    Icon(Icons.Default.Warning, null, tint = accentRed, modifier = Modifier.size(16.dp).scale(micScale))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("DANGER: \"${state.detectedPhrase}\"", color = accentRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun VoiceWaveform(isListening: Boolean, rms: Float) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(15) { index ->
            val height by animateFloatAsState(
                targetValue = if (isListening) (rms.coerceAtLeast(0f) / 10f) + (Math.random().toFloat() * 0.5f) else 0.1f,
                animationSpec = tween(100 + index * 20),
                label = ""
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height((30 * height + 4).dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF00F2FF), Color(0xFF0066FF))))
            )
        }
    }
}

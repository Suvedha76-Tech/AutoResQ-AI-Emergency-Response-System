// ============================================================
// FirstAidScreen.kt
// ============================================================
package com.roadsos.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

data class FirstAidStep(
    val number: Int,
    val title: String,
    val description: String,
    val urgency: String = "NORMAL"
)

val firstAidSteps = listOf(
    FirstAidStep(1, "Ensure Safety", "Do not approach if there's fire, traffic, or electrical hazard. Make area safe first.", "HIGH"),
    FirstAidStep(2, "Check Consciousness", "Tap shoulders gently. Call out loudly: 'Are you okay?'. Note response level.", "HIGH"),
    FirstAidStep(3, "Check Breathing", "Tilt head back, lift chin. Look, listen, feel for 10 seconds.", "HIGH"),
    FirstAidStep(4, "Call Emergency", "Dial 108 (Ambulance) or 112 (Emergency). Stay on line with dispatcher.", "HIGH"),
    FirstAidStep(5, "Stop Bleeding", "Apply firm pressure with clean cloth. Don't remove it. Elevate limb if possible.", "NORMAL"),
    FirstAidStep(6, "CPR if Needed", "30 hard chest compressions then 2 rescue breaths. Push 5cm deep at 100/min.", "NORMAL"),
    FirstAidStep(7, "Don't Move Victim", "Avoid moving unless in immediate danger. Suspect spinal injury in all crashes.", "NORMAL"),
    FirstAidStep(8, "Stay Until Help Arrives", "Keep victim warm, calm, and monitored. Report all changes to dispatcher.", "NORMAL")
)

@Composable
fun FirstAidScreen(onBack: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0A0A12)) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Color.White)
                    }
                    Column {
                        Text("First Aid Guide", fontSize = 17.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Emergency response steps", fontSize = 11.sp, color = Color(0x66FFFFFF))
                    }
                }
                // Emergency Numbers Card
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x15E24B4A)),
                    border = BorderStroke(0.5.dp, Color(0x40E24B4A)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        EmergencyNumber("108", "Ambulance")
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = Color(0x30FFFFFF))
                        EmergencyNumber("100", "Police")
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = Color(0x30FFFFFF))
                        EmergencyNumber("101", "Fire")
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = Color(0x30FFFFFF))
                        EmergencyNumber("112", "All")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("STEPS", fontSize = 10.sp, color = Color(0x66FFFFFF), fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            items(firstAidSteps) { step ->
                FirstAidCard(step = step)
            }
        }
    }
}

@Composable
fun EmergencyNumber(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(number, fontSize = 18.sp, color = Color(0xFFE24B4A), fontWeight = FontWeight.Bold)
        Text(label, fontSize = 9.sp, color = Color(0x88FFFFFF))
    }
}

@Composable
fun FirstAidCard(step: FirstAidStep) {
    val isHigh = step.urgency == "HIGH"
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHigh) Color(0x15E24B4A) else Color(0x0AFFFFFF)
        ),
        border = BorderStroke(0.5.dp, if (isHigh) Color(0x40E24B4A) else Color(0x1AFFFFFF)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier.size(32.dp).clip(CircleShape)
                    .background(if (isHigh) Color(0x30E24B4A) else Color(0x20FFFFFF))
                    .border(1.dp, if (isHigh) Color(0x60E24B4A) else Color(0x30FFFFFF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("${step.number}", fontSize = 13.sp, color = if (isHigh) Color(0xFFE24B4A) else Color.White, fontWeight = FontWeight.Bold)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(step.title, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(step.description, fontSize = 11.sp, color = Color(0x88FFFFFF), modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

package com.roadsos.app.viewmodel

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.FirebaseFirestore
import com.roadsos.app.data.local.UserPreferences
import com.roadsos.app.data.model.*
import com.roadsos.app.repository.EmergencyRepository
import com.roadsos.app.service.AccidentDetectionService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.ExperimentalCoroutinesApi

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = EmergencyRepository()
    private val hospitalRepo = com.roadsos.app.repository.HospitalRepository()
    private val serviceRepo = com.roadsos.app.repository.EmergencyServiceRepository()
    private val context: Context get() = getApplication()
    private val userPrefs = UserPreferences(context)
    private var mediaPlayer: MediaPlayer? = null
    private val db = FirebaseFirestore.getInstance()

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _activeEmergencies = MutableStateFlow<List<Emergency>>(emptyList())
    val activeEmergencies: StateFlow<List<Emergency>> = _activeEmergencies.asStateFlow()

    private val _nearbyUsers = MutableStateFlow<List<User>>(emptyList())
    val nearbyUsers: StateFlow<List<User>> = _nearbyUsers.asStateFlow()

    private val _nearbyHospitals = MutableStateFlow<List<Hospital>>(emptyList())
    val nearbyHospitals: StateFlow<List<Hospital>> = _nearbyHospitals.asStateFlow()

    private val _currentLocation = MutableStateFlow<Pair<Double, Double>?>(null)
    val currentLocation: StateFlow<Pair<Double, Double>?> = _currentLocation.asStateFlow()

    private val _selectedServiceType = MutableStateFlow(ServiceType.HOSPITAL)
    val selectedServiceType: StateFlow<ServiceType> = _selectedServiceType.asStateFlow()

    private val _protectionActive = MutableStateFlow(true)
    val protectionActive: StateFlow<Boolean> = _protectionActive.asStateFlow()

    private val _cloudSyncReady = MutableStateFlow(true)
    val cloudSyncReady: StateFlow<Boolean> = _cloudSyncReady.asStateFlow()

    private val _gpsConnected = _currentLocation.map { it != null }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val gpsConnected: StateFlow<Boolean> = _gpsConnected

    fun toggleProtection() {
        _protectionActive.value = !_protectionActive.value
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val nearbyServices: StateFlow<List<EmergencyService>> = combine(
        _currentLocation.filterNotNull(),
        _selectedServiceType
    ) { loc, type -> loc to type }
        .flatMapLatest { (loc, type) ->
            flow {
                emit(serviceRepo.getNearbyServices(loc.first, loc.second, type))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveSOSAlerts: StateFlow<List<SOSAlert>> = _activeEmergencies.map { list ->
        list.map { emer ->
            SOSAlert(
                id = emer.emergencyId,
                userId = emer.userId,
                username = emer.username,
                profileImage = emer.avatarUrl,
                latitude = emer.latitude,
                longitude = emer.longitude,
                address = emer.address,
                emergencyType = emer.emergencyType,
                batteryLevel = emer.batteryPercent,
                networkStrength = emer.networkStrength,
                riskLevel = emer.aiRiskLevel,
                aiConfidence = emer.aiConfidence,
                timestamp = emer.timestamp,
                status = emer.status,
                helperCount = emer.respondersCount,
                responderETA = emer.responderETA,
                active = emer.active,
                deviceId = emer.deviceId,
                verifiedUser = emer.isVerified,
                responderId = emer.responderId,
                responderName = emer.responderName
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _incomingAlert = MutableStateFlow<Emergency?>(null)
    val incomingAlert: StateFlow<Emergency?> = _incomingAlert.asStateFlow()

    private val _showEvidenceCountdown = MutableStateFlow(false)
    val showEvidenceCountdown = _showEvidenceCountdown.asStateFlow()

    private val _showVictimPopup = MutableSharedFlow<Pair<String, String>>()
    val showVictimPopup = _showVictimPopup.asSharedFlow()

    private var helperTrackingJob: Job? = null
    private var myEmergencyListener: com.google.firebase.firestore.ListenerRegistration? = null

    init {
        startRealtimeEmergencySync()
        startSelfLocationUpdates()
    }

    fun triggerEvidenceShield(reason: String) {
        viewModelScope.launch {
            if (reason == "AI_VOICE") {
                _showEvidenceCountdown.value = true
                delay(3000)
                if (_showEvidenceCountdown.value) {
                    activateEvidenceShield()
                }
            } else {
                activateEvidenceShield()
            }
        }
    }

    fun cancelEvidenceShield() {
        _showEvidenceCountdown.value = false
    }

    private fun activateEvidenceShield() {
        _showEvidenceCountdown.value = false
        val intent = Intent(context, com.roadsos.app.service.EvidenceShieldService::class.java)
        ContextCompat.startForegroundService(context, intent)
        vibrate(500)
    }

    private fun startRealtimeEmergencySync() {
        viewModelScope.launch {
            val myPhone = userPrefs.userPhone.first()
            repo.listenToActiveEmergencies().collect { emergencies ->
                // 1. SELF FILTERING: Hide own SOS
                val othersEmergencies = emergencies.filter { it.userId != myPhone }
                
                // 2. NEARBY FILTERING (5km)
                val myLoc = _currentLocation.value
                val nearby = othersEmergencies.filter { emer ->
                    if (myLoc != null) {
                        repo.calculateDistance(myLoc.first, myLoc.second, emer.latitude, emer.longitude) <= 5.0
                    } else true
                }

                // 3. UPDATE UI STATE
                _activeEmergencies.value = nearby
                _uiState.update { it.copy(activeEmergencyCount = nearby.size) }

                // 4. DETECT NEW NEARBY SOS FOR POPUP & SOUND
                val currentIds = _activeEmergencies.value.map { it.emergencyId }.toSet()
                nearby.forEach { alert ->
                    if (alert.emergencyId !in currentIds && alert.status == "AWAITING_RESPONDERS") {
                        triggerLocalAlert(alert)
                    }
                }
            }
        }
    }

    private fun triggerLocalAlert(alert: Emergency) {
        _incomingAlert.value = alert
        playAlertSound()
        vibrate(500)
        showCommunityAlertNotification(alert)
    }

    private fun showCommunityAlertNotification(alert: Emergency) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "community_alerts"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Community Alerts", NotificationManager.IMPORTANCE_HIGH)
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, com.roadsos.app.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(com.roadsos.app.R.drawable.ic_warning)
            .setContentTitle("🚨 EMERGENCY NEARBY: ${alert.username}")
            .setContentText("Needs help ${alert.address}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        notificationManager.notify(alert.emergencyId.hashCode(), builder.build())
    }

    private fun playAlertSound() {
        try {
            val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE) ?: 
                           RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(context, alertUri)
            mediaPlayer?.start()
            // Stop after 5 seconds to not be annoying
            viewModelScope.launch {
                delay(5000)
                mediaPlayer?.stop()
            }
        } catch (e: Exception) {
            Log.e("ALERT", "Sound failed", e)
        }
    }

    private fun vibrate(duration: Long) {
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") vibrator.vibrate(duration)
        }
    }

    private fun startSelfLocationUpdates() {
        viewModelScope.launch {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            while (isActive) {
                try {
                    val location = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                    if (location != null) {
                        val userId = userPrefs.userPhone.first()
                        if (userId.isNotBlank()) {
                            repo.updateUserLocation(userId, location.latitude, location.longitude)
                        }
                        _currentLocation.value = Pair(location.latitude, location.longitude)
                        fetchNearbyData(location.latitude, location.longitude)
                    }
                } catch (e: Exception) {
                    Log.e("LOCATION", "Self update failed", e)
                }
                delay(10000)
            }
        }
    }

    private fun fetchNearbyData(lat: Double, lng: Double) {
        viewModelScope.launch {
            try {
                // Fetch Nearby Hospitals
                val hospitals = hospitalRepo.getNearbyHospitals(lat, lng)
                _nearbyHospitals.value = hospitals

                // Fetch Nearby Users
                val allUsers = repo.getAllUsers()
                val myPhone = userPrefs.userPhone.first()
                val nearby = allUsers.filter { user ->
                    user.phone != myPhone && repo.calculateDistance(lat, lng, user.latitude, user.longitude) <= 5.0
                }
                _nearbyUsers.value = nearby
            } catch (e: Exception) {
                Log.e("DATA", "Nearby fetch failed", e)
            }
        }
    }

    fun onICanHelp(emergency: Emergency) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val myLoc = _currentLocation.value ?: return@launch
            val myPhone = userPrefs.userPhone.first()
            
            var myName = "Responder"
            try {
                val userDoc = db.collection("users").document(myPhone).get().await()
                myName = userDoc.getString("name") ?: "Responder"
            } catch (e: Exception) {}

            repo.acceptHelp(emergency.emergencyId, myPhone, myName, myLoc.first, myLoc.second)
            
            _incomingAlert.value = null
            _uiState.update { it.copy(isLoading = false, statusMessage = "Navigating to ${emergency.username}") }
            
            startHelperTracking(emergency.emergencyId)
        }
    }

    fun acceptSOS(alertId: String) {
        val emergency = _activeEmergencies.value.find { it.emergencyId == alertId }
        emergency?.let { onICanHelp(it) }
    }

    fun resolveSOS(alertId: String) {
        viewModelScope.launch {
            repo.updateEmergencyStatus(alertId, "RESOLVED")
        }
    }

    fun setServiceType(type: ServiceType) {
        _selectedServiceType.value = type
    }

    private fun startHelperTracking(emergencyId: String) {
        helperTrackingJob?.cancel()
        helperTrackingJob = viewModelScope.launch {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            while (isActive) {
                try {
                    val location = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                    if (location != null) {
                        val emerDoc = db.collection("active_emergencies").document(emergencyId).get().await()
                        val emer = emerDoc.data?.toEmergency(emergencyId)
                        if (emer == null || emer.status == "RESOLVED" || !emer.active) break
                        
                        val distKm = repo.calculateDistance(location.latitude, location.longitude, emer.latitude, emer.longitude)
                        val eta = if (distKm < 0.1) "Arrived" else "${(distKm * 2 + 1).toInt()} min"
                        
                        repo.updateResponderPosition(emergencyId, location.latitude, location.longitude, eta)
                        
                        if (distKm < 0.05) {
                            repo.updateEmergencyStatus(emergencyId, "RESPONDER_ARRIVED")
                        }
                    }
                } catch (e: Exception) {
                    Log.e("TRACKING", "Helper tracking failed", e)
                }
                delay(5000)
            }
        }
    }

    fun triggerRealtimeCommunitySOS(emergencyType: String = "Medical Emergency") {
        viewModelScope.launch {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            try {
                val location = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await() ?: return@launch
                val myPhone = userPrefs.userPhone.first()
                
                var myName = "User"
                var myAvatar = ""
                var verified = false
                try {
                    val userDoc = db.collection("users").document(myPhone).get().await()
                    myName = userDoc.getString("name") ?: "User"
                    myAvatar = userDoc.getString("avatarUrl") ?: ""
                    verified = userDoc.getBoolean("isVerified") ?: false
                } catch (e: Exception) {}

                val geocoder = android.location.Geocoder(context, java.util.Locale.getDefault())
                val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                val addressStr = addresses?.firstOrNull()?.getAddressLine(0) ?: "Unknown Location"

                val emergency = Emergency(
                    userId = myPhone,
                    username = myName,
                    avatarUrl = myAvatar,
                    isVerified = verified,
                    emergencyType = emergencyType,
                    latitude = location.latitude,
                    longitude = location.longitude,
                    address = addressStr,
                    timestamp = com.google.firebase.Timestamp.now(),
                    status = "AWAITING_RESPONDERS",
                    batteryPercent = 85,
                    networkStrength = 4,
                    aiRiskLevel = "HIGH",
                    aiRiskScore = 92,
                    deviceId = android.os.Build.MODEL,
                    active = true,
                    lastUpdated = com.google.firebase.Timestamp.now()
                )

                val docRef = db.collection("active_emergencies").add(emergency.toMap()).await()
                _uiState.update { it.copy(sosTriggered = true, currentEmergencyId = docRef.id) }
                
                listenToMyEmergency(docRef.id)
            } catch (e: Exception) {
                Log.e("SOS", "Trigger failed", e)
            }
        }
    }

    private fun listenToMyEmergency(id: String) {
        myEmergencyListener?.remove()
        myEmergencyListener = db.collection("active_emergencies").document(id)
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null && snapshot.exists()) {
                    val emer = snapshot.data?.toEmergency(id)
                    if (emer != null) {
                        if (emer.status == "RESPONDER_ASSIGNED" || emer.status == "HELP_ON_THE_WAY") {
                            viewModelScope.launch {
                                _showVictimPopup.emit(Pair(emer.responderName ?: "Responder", emer.responderETA))
                            }
                            _uiState.update { it.copy(statusMessage = "Help is on the way: ${emer.responderName}") }
                            vibrate(1000)
                        } else if (emer.status == "RESPONDER_ARRIVED") {
                            _uiState.update { it.copy(statusMessage = "Responder has arrived!") }
                        }
                    }
                }
            }
    }

    fun resolveEmergency() {
        val id = _uiState.value.currentEmergencyId ?: return
        viewModelScope.launch {
            repo.updateEmergencyStatus(id, "RESOLVED")
            _uiState.update { it.copy(sosTriggered = false, statusMessage = "Emergency Resolved") }
            myEmergencyListener?.remove()
        }
    }

    fun dismissAlert() {
        _incomingAlert.value = null
    }

    fun triggerDemoAccident() {
        AccidentDetectionService.simulateDemoAccident(context)
    }

    fun getUser(phone: String, callback: (Map<String, Any>?) -> Unit) {
        if (phone.isBlank()) {
            callback(null)
            return
        }
        db.collection("users").document(phone).get()
            .addOnSuccessListener { snapshot ->
                callback(snapshot.data)
            }
            .addOnFailureListener {
                callback(null)
            }
    }

    fun updateUser(phone: String, data: Map<String, Any>) {
        if (phone.isBlank()) return
        db.collection("users").document(phone).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener {
                Log.d("UPDATE_USER", "Success")
            }
            .addOnFailureListener { e ->
                Log.e("UPDATE_USER", "Failed", e)
            }
    }

    fun saveUserToFirebase(
        name: String,
        phone: String,
        age: Int,
        contact1: String,
        contact2: String,
        vehicle: String,
        bloodGroup: String
    ) {
        val data = mapOf(
            "name" to name,
            "phone" to phone,
            "age" to age,
            "contact1" to contact1,
            "contact2" to contact2,
            "vehicle" to vehicle,
            "bloodGroup" to bloodGroup,
            "isVerified" to false,
            "latitude" to 0.0,
            "longitude" to 0.0
        )
        updateUser(phone, data)
    }

    override fun onCleared() {
        super.onCleared()
        helperTrackingJob?.cancel()
        mediaPlayer?.release()
        myEmergencyListener?.remove()
    }
}

data class MainUiState(
    val isLoading: Boolean = false,
    val sosTriggered: Boolean = false,
    val currentEmergencyId: String? = null,
    val statusMessage: String = "Monitoring active",
    val error: String? = null,
    val activeEmergencyCount: Int = 0
)

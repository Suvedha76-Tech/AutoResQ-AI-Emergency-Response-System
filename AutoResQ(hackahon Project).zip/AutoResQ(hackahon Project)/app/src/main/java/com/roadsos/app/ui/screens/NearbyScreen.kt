package com.roadsos.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roadsos.app.data.model.EmergencyService
import com.roadsos.app.data.model.ServiceType
import com.roadsos.app.viewmodel.MainViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

@Composable
fun NearbyScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val services by viewModel.nearbyServices.collectAsStateWithLifecycle()
    val selectedType by viewModel.selectedServiceType.collectAsStateWithLifecycle()
    val myLoc by viewModel.currentLocation.collectAsStateWithLifecycle()
    
    var selectedService by remember { mutableStateOf<EmergencyService?>(null) }
    var isMapExpanded by remember { mutableStateOf(false) }

    // Theme Colors
    val neonCyan = Color(0xFF00F2FF)
    val glassBg = Color(0xCC0D0D1A)
    val darkBg = Color(0xFF020205)

    LaunchedEffect(services) {
        if (selectedService == null && services.isNotEmpty()) {
            selectedService = services.first()
        } else if (services.isNotEmpty() && !services.any { it.id == selectedService?.id }) {
            selectedService = services.first()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(darkBg)) {
        // Futuristic Gradient Background
        Box(modifier = Modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(Color(0x2200F2FF), Color.Transparent),
                radius = 1000f
            )
        ))

        Column(modifier = Modifier.fillMaxSize()) {
            // Glassmorphism Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .statusBarsPadding()
                    .clip(RoundedCornerShape(24.dp))
                    .background(glassBg)
                    .border(0.5.dp, Color(0x3000FFFF), RoundedCornerShape(24.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.clip(CircleShape).background(Color(0x20FFFFFF))) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = neonCyan)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("EMERGENCY LOCATOR", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        NearbyLivePulse()
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SATELLITE SYNC ACTIVE", color = neonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Category Selector
            CategorySelector(selectedType, neonCyan) { viewModel.setServiceType(it) }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                // Interactive Map Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .height(if (isMapExpanded) 400.dp else 220.dp)
                            .animateContentSize(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color(0x3000FFFF))
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            MapWidget(
                                myLoc = myLoc,
                                services = services,
                                selectedService = selectedService,
                                onServiceSelect = { selectedService = it }
                            )
                            
                            // Map Overlay Controls
                            IconButton(
                                onClick = { isMapExpanded = !isMapExpanded },
                                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).background(glassBg, CircleShape)
                            ) {
                                Icon(if (isMapExpanded) Icons.Default.CloseFullscreen else Icons.Default.OpenInFull, null, tint = neonCyan)
                            }
                        }
                    }
                }

                // AI Recommendation
                selectedService?.let {
                    item {
                        AIRecommendationBanner(it)
                    }
                }

                // Service List
                if (services.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = neonCyan)
                        }
                    }
                } else {
                    items(services) { service ->
                        ServiceDashboardCard(
                            service = service,
                            isSelected = selectedService?.id == service.id,
                            neonCyan = neonCyan,
                            glassBg = glassBg,
                            onClick = { selectedService = service }
                        )
                    }
                }
            }
        }

        // Floating Action Buttons
        Column(
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FloatingActionButton(
                onClick = { 
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "I need help! My location: https://www.google.com/maps/search/?api=1&query=${myLoc?.first},${myLoc?.second}")
                    }
                    context.startActivity(Intent.createChooser(intent, "Share Location"))
                },
                containerColor = glassBg,
                contentColor = neonCyan,
                shape = CircleShape,
                modifier = Modifier.size(56.dp).border(1.dp, neonCyan.copy(0.5f), CircleShape)
            ) {
                Icon(Icons.Default.ShareLocation, "Share Location")
            }

            FloatingActionButton(
                onClick = { 
                    val lat = myLoc?.first ?: 13.0827
                    val lng = myLoc?.second ?: 80.2707
                    val intent = Intent(context, EmergencyAlertActivity::class.java).apply {
                        putExtra("latitude", lat)
                        putExtra("longitude", lng)
                        putExtra("isDemoMode", false)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                },
                containerColor = Color(0xFFFF003C),
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.size(64.dp)
            ) {
                Icon(Icons.Default.Sos, "SOS", modifier = Modifier.size(32.dp))
            }
        }
    }
}

@Composable
fun MapWidget(
    myLoc: Pair<Double, Double>?,
    services: List<EmergencyService>,
    selectedService: EmergencyService?,
    onServiceSelect: (EmergencyService) -> Unit
) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            Configuration.getInstance().load(context, context.getSharedPreferences("osm", Context.MODE_PRIVATE))
            MapView(context).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                setMultiTouchControls(true)
                controller.setZoom(15.0)
                
                // Dark Theme Map Filter
                val inverseMatrix = floatArrayOf(
                    -1.0f, 0.0f, 0.0f, 0.0f, 255.0f,
                    0.0f, -1.0f, 0.0f, 0.0f, 255.0f,
                    0.0f, 0.0f, -1.0f, 0.0f, 255.0f,
                    0.0f, 0.0f, 0.0f, 1.0f, 0.0f
                )
                overlayManager.tilesOverlay.setColorFilter(android.graphics.ColorMatrixColorFilter(inverseMatrix))
            }
        },
        update = { mapView ->
            mapView.overlays.clear()
            
            myLoc?.let { loc ->
                val myPos = GeoPoint(loc.first, loc.second)
                val myMarker = Marker(mapView).apply {
                    position = myPos
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    icon = androidx.appcompat.content.res.AppCompatResources.getDrawable(context, android.R.drawable.presence_online)
                }
                mapView.overlays.add(myMarker)
                
                selectedService?.let { service ->
                    val servicePos = GeoPoint(service.latitude, service.longitude)
                    val line = Polyline().apply {
                        setPoints(listOf(myPos, servicePos))
                        outlinePaint.color = android.graphics.Color.CYAN
                        outlinePaint.strokeWidth = 8f
                    }
                    mapView.overlays.add(line)
                    mapView.controller.animateTo(servicePos)
                } ?: mapView.controller.animateTo(myPos)
            }

            services.forEach { service ->
                val marker = Marker(mapView).apply {
                    position = GeoPoint(service.latitude, service.longitude)
                    title = service.name
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    icon = androidx.appcompat.content.res.AppCompatResources.getDrawable(context, getServiceIconRes(service.type))
                    setOnMarkerClickListener { _, _ ->
                        onServiceSelect(service)
                        true
                    }
                }
                mapView.overlays.add(marker)
            }
            mapView.invalidate()
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun CategorySelector(selected: ServiceType, neonCyan: Color, onSelect: (ServiceType) -> Unit) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(ServiceType.entries.toTypedArray()) { type ->
            val isSelected = selected == type
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelect(type) },
                color = if (isSelected) neonCyan else Color(0x300A0A1A),
                border = BorderStroke(0.5.dp, if (isSelected) Color.White else Color(0x3000FFFF)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        getServiceIcon(type),
                        contentDescription = null,
                        tint = if (isSelected) Color.Black else Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        type.name.replace("_", " "),
                        color = if (isSelected) Color.Black else Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun AIRecommendationBanner(service: EmergencyService) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        color = Color(0x1A00FF9D),
        border = BorderStroke(1.dp, Color(0xFF00FF9D).copy(0.3f))
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF00FF9D), modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                "AI Recommendation: ${service.name} has the lowest traffic and highest ER readiness score (98%).",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ServiceDashboardCard(
    service: EmergencyService,
    isSelected: Boolean,
    neonCyan: Color,
    glassBg: Color,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 1.dp else 0.5.dp,
                color = if (isSelected) neonCyan else Color(0x3000FFFF),
                shape = RoundedCornerShape(24.dp)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = if(isSelected) glassBg else Color(0x800A0A12))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(neonCyan.copy(0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(getServiceIcon(service.type), null, tint = neonCyan, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(service.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("OPEN 24/7 • ${service.status}", color = neonCyan, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("SAFETY SCORE", color = Color.Gray, fontSize = 7.sp, fontWeight = FontWeight.Black)
                    Text("98/100", color = Color(0xFF00FF9D), fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ServiceMetricBox(Icons.Default.Route, service.distanceStr, "DISTANCE", Modifier.weight(1f))
                ServiceMetricBox(Icons.Default.Timer, "${service.eta} MIN", "ETA", Modifier.weight(1f), neonCyan)
                ServiceMetricBox(Icons.Default.Star, service.rating.toString(), "RATING", Modifier.weight(1f), Color(0xFFFFC107))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val gmmIntentUri = Uri.parse("google.navigation:q=${service.latitude},${service.longitude}")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                            setPackage("com.google.android.apps.maps")
                        }
                        context.startActivity(mapIntent)
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = neonCyan),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Navigation, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("NAVIGATE", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }

                IconButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${service.phone}"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x1AFFFFFF)).border(0.5.dp, Color.White.copy(0.2f), RoundedCornerShape(12.dp))
                ) {
                    Icon(Icons.Default.Phone, null, tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun ServiceMetricBox(icon: ImageVector, value: String, label: String, modifier: Modifier = Modifier, color: Color = Color.White) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x0AFFFFFF)).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = color.copy(0.6f), modifier = Modifier.size(14.dp))
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Text(label, color = Color.Gray, fontSize = 7.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NearbyLivePulse() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "alpha")
    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF00FF9D).copy(alpha = alpha)))
}

fun getServiceIcon(type: ServiceType): ImageVector = when (type) {
    ServiceType.HOSPITAL -> Icons.Default.LocalHospital
    ServiceType.POLICE -> Icons.Default.LocalPolice
    ServiceType.FUEL -> Icons.Default.LocalGasStation
    ServiceType.EV_CHARGING -> Icons.Default.EvStation
    ServiceType.PARKING -> Icons.Default.LocalParking
}

fun getServiceIconRes(type: ServiceType): Int = when (type) {
    ServiceType.HOSPITAL -> android.R.drawable.ic_menu_myplaces
    ServiceType.POLICE -> android.R.drawable.ic_menu_compass
    ServiceType.FUEL -> android.R.drawable.ic_menu_send
    ServiceType.EV_CHARGING -> android.R.drawable.ic_menu_add
    ServiceType.PARKING -> android.R.drawable.ic_menu_gallery
}

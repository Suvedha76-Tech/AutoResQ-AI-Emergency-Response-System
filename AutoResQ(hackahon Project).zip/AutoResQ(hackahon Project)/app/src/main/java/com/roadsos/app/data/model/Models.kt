package com.roadsos.app.data.model

import com.google.firebase.Timestamp

data class Emergency(
    val emergencyId: String = "",
    val userId: String = "",
    val username: String = "",
    val avatarUrl: String = "",
    val isVerified: Boolean = false,
    val emergencyType: String = "Medical Emergency",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val address: String = "",
    val timestamp: Timestamp = Timestamp.now(),
    val status: String = "AWAITING_RESPONDERS",
    val responderId: String? = null,
    val responderName: String? = null,
    val responderLat: Double? = null,
    val responderLng: Double? = null,
    val responderETA: String = "",
    val ambulanceCalled: Boolean = false,
    val ambulanceETA: String = "",
    val aiRiskLevel: String = "MODERATE", // CRITICAL / HIGH / MODERATE / LOW
    val aiRiskScore: Int = 0, // 0–100
    val aiConfidence: Int = 90,
    val batteryPercent: Int = 100,
    val networkStrength: Int = 5,
    val respondersCount: Int = 0,
    val radius: Double = 5.0,
    val priority: String = "NORMAL",
    val primaryHelperId: String = "",
    val deviceId: String = "",
    val active: Boolean = true,
    val lastUpdated: Timestamp = Timestamp.now()
)

enum class EmergencyStatus {
    ACTIVE, RESOLVED, FALSE_ALARM, HELP_ON_WAY, ESCALATED, RESPONDER_ASSIGNED, RESPONDER_ARRIVED
}

data class User(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val fcmToken: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val isAvailable: Boolean = true,
    val bloodGroup: String = "N/A",
    val trustScore: Int = 95
)

data class Helper(
    val userId: String = "",
    val name: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val eta: String = "",
    val status: HelperStatus = HelperStatus.ALERTED,
    val distance: String = ""
)

enum class HelperStatus {
    ALERTED, RESPONDING, ARRIVED
}

data class AccidentEvent(
    val accelerationMagnitude: Float = 0f,
    val speedBefore: Float = 0f,
    val speedAfter: Float = 0f,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
)

data class Hospital(
    val id: String = "",
    val name: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val address: String = "",
    val phone: String = "",
    val rating: Float = 0f,
    val isEmergencyAvailable: Boolean = true,
    val distance: String = "",
    val eta: String = ""
)

data class SOSAlert(
    val id: String = "",
    val userId: String = "",
    val username: String = "",
    val profileImage: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val address: String = "",
    val emergencyType: String = "Medical Emergency",
    val batteryLevel: Int = 85,
    val networkStrength: Int = 4,
    val riskLevel: String = "HIGH",
    val aiConfidence: Int = 92,
    val timestamp: Timestamp = Timestamp.now(),
    val status: String = "Awaiting Responders",
    val helperCount: Int = 0,
    val responderETA: String = "Calculating...",
    val active: Boolean = true,
    val deviceId: String = "",
    val verifiedUser: Boolean = false,
    val responderId: String? = null,
    val responderName: String? = null
)

enum class ServiceType {
    HOSPITAL, POLICE, FUEL, EV_CHARGING, PARKING
}

data class EmergencyService(
    val id: String = "",
    val name: String = "",
    val type: ServiceType = ServiceType.HOSPITAL,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val address: String = "",
    val phone: String = "",
    val distance: Double = 0.0,
    val distanceStr: String = "",
    val eta: Int = 0,
    val status: String = "Open 24/7",
    val rating: Float = 4.5f
)

// Firestore document extensions
fun Emergency.toMap(): Map<String, Any?> = mapOf(
    "emergencyId" to emergencyId,
    "userId" to userId,
    "username" to username,
    "avatarUrl" to avatarUrl,
    "isVerified" to isVerified,
    "emergencyType" to emergencyType,
    "latitude" to latitude,
    "longitude" to longitude,
    "address" to address,
    "timestamp" to timestamp,
    "status" to status,
    "responderId" to responderId,
    "responderName" to responderName,
    "responderLat" to responderLat,
    "responderLng" to responderLng,
    "responderETA" to responderETA,
    "ambulanceCalled" to ambulanceCalled,
    "ambulanceETA" to ambulanceETA,
    "aiRiskLevel" to aiRiskLevel,
    "aiRiskScore" to aiRiskScore,
    "aiConfidence" to aiConfidence,
    "batteryPercent" to batteryPercent,
    "networkStrength" to networkStrength,
    "respondersCount" to respondersCount,
    "radius" to radius,
    "priority" to priority,
    "primaryHelperId" to primaryHelperId,
    "deviceId" to deviceId,
    "active" to active,
    "lastUpdated" to lastUpdated
)

fun Map<String, Any?>.toEmergency(id: String): Emergency = Emergency(
    emergencyId = id,
    userId = this["userId"] as? String ?: "",
    username = this["username"] as? String ?: (this["userName"] as? String ?: ""),
    avatarUrl = this["avatarUrl"] as? String ?: "",
    isVerified = this["isVerified"] as? Boolean ?: false,
    emergencyType = this["emergencyType"] as? String ?: "Medical Emergency",
    latitude = (this["latitude"] as? Double) ?: 0.0,
    longitude = (this["longitude"] as? Double) ?: 0.0,
    address = this["address"] as? String ?: "",
    timestamp = this["timestamp"] as? Timestamp ?: Timestamp.now(),
    status = this["status"] as? String ?: "AWAITING_RESPONDERS",
    responderId = this["responderId"] as? String,
    responderName = this["responderName"] as? String,
    responderLat = this["responderLat"] as? Double,
    responderLng = this["responderLng"] as? Double,
    responderETA = this["responderETA"] as? String ?: "",
    ambulanceCalled = this["ambulanceCalled"] as? Boolean ?: false,
    ambulanceETA = this["ambulanceETA"] as? String ?: "",
    aiRiskLevel = this["aiRiskLevel"] as? String ?: "MODERATE",
    aiRiskScore = (this["aiRiskScore"] as? Long)?.toInt() ?: 0,
    aiConfidence = (this["aiConfidence"] as? Long)?.toInt() ?: 90,
    batteryPercent = (this["batteryPercent"] as? Long)?.toInt() ?: 100,
    networkStrength = (this["networkStrength"] as? Long)?.toInt() ?: 5,
    respondersCount = (this["respondersCount"] as? Long)?.toInt() ?: (this["helpersCount"] as? Long)?.toInt() ?: 0,
    radius = (this["radius"] as? Double) ?: 5.0,
    priority = this["priority"] as? String ?: "NORMAL",
    primaryHelperId = this["primaryHelperId"] as? String ?: "",
    deviceId = this["deviceId"] as? String ?: "",
    active = this["active"] as? Boolean ?: true,
    lastUpdated = this["lastUpdated"] as? Timestamp ?: Timestamp.now()
)

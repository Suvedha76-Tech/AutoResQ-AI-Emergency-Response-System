package com.roadsos.app.ui.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.roadsos.app.databinding.BottomSheetVictimHelpBinding

class VictimHelpBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetVictimHelpBinding? = null
    private val binding get() = _binding!!

    var responderName: String = ""
    var eta: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = BottomSheetVictimHelpBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        binding.tvStatus.text = "Help is on the way"
        binding.tvResponderName.text = responderName
        binding.tvEta.text = "ETA: $eta"
        
        // Animated progress bar
        binding.progressBar.isIndeterminate = true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance(responderName: String, eta: String): VictimHelpBottomSheet {
            return VictimHelpBottomSheet().apply {
                this.responderName = responderName
                this.eta = eta
            }
        }
    }
}

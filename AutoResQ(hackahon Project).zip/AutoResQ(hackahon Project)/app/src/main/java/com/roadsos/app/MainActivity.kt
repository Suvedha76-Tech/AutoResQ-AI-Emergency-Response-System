package com.roadsos.app

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.firebase.FirebaseApp
import com.roadsos.app.service.AccidentDetectionService
import com.roadsos.app.ui.screens.*
import com.roadsos.app.ui.theme.RoadSoSTheme
import com.roadsos.app.viewmodel.MainViewModel
import com.roadsos.app.ui.components.LiveEmergencyPopup
import kotlinx.coroutines.delay

class RoadSoSApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
    }
}

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            checkLocationSettings()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkAndRequestPermissions()
        setContent {
            val showCountdown by viewModel.showEvidenceCountdown.collectAsState()
            
            LaunchedEffect(Unit) {
                com.roadsos.app.viewmodel.AIVoiceViewModel.dangerDetected.collect {
                    viewModel.triggerEvidenceShield("AI_VOICE")
                }
            }

            LaunchedEffect(viewModel.showVictimPopup) {
                viewModel.showVictimPopup.collect { (name, eta) ->
                    com.roadsos.app.ui.dialog.VictimHelpBottomSheet.newInstance(name, eta)
                        .show(this@MainActivity.supportFragmentManager, "VictimHelp")
                }
            }
            RoadSoSTheme {
                Box(modifier = Modifier.fillMaxSize()) {
                    RoadSoSNavHost(viewModel = viewModel)
                    
                    if (showCountdown) {
                        EvidenceCountdownOverlay(
                            onCancel = { viewModel.cancelEvidenceShield() }
                        )
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsNeeded = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.VIBRATE,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permissionsNeeded.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) permissionsNeeded.add(Manifest.permission.FOREGROUND_SERVICE_LOCATION)

        val listToRequest = permissionsNeeded.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (listToRequest.isNotEmpty()) permissionsLauncher.launch(listToRequest.toTypedArray())
        else checkLocationSettings()
    }

    private fun checkLocationSettings() {
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).build()
        val builder = LocationSettingsRequest.Builder().addLocationRequest(locationRequest)
        val client = LocationServices.getSettingsClient(this)
        client.checkLocationSettings(builder.build()).addOnSuccessListener { startDetectionService() }
            .addOnFailureListener { exception ->
                if (exception is ResolvableApiException) {
                    try { exception.startResolutionForResult(this, 1001) } catch (e: Exception) {}
                }
            }
    }

    private fun startDetectionService() {
        try { startForegroundService(Intent(this, AccidentDetectionService::class.java)) } catch (e: Exception) {}
    }
}

@Composable
fun EvidenceCountdownOverlay(onCancel: () -> Unit) {
    var secondsLeft by remember { mutableIntStateOf(3) }
    
    LaunchedEffect(Unit) {
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.8f))
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🛡 Evidence Shield", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Potential danger detected", color = Color(0xFFE53935), fontSize = 16.sp)
            Spacer(modifier = Modifier.height(32.dp))
            
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { secondsLeft / 3f },
                    modifier = Modifier.size(100.dp),
                    color = Color(0xFFE53935),
                    strokeWidth = 8.dp
                )
                Text("$secondsLeft", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            Button(
                onClick = onCancel,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("CANCEL ACTIVATION", color = Color.White)
            }
        }
    }
}

data class BottomNavItem(val route: String, val label: String, val icon: ImageVector)

@Composable
fun RoadSoSNavHost(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val incomingAlert by viewModel.incomingAlert.collectAsState()

    val items = listOf(
        BottomNavItem("home", "Home", Icons.Default.Home),
        BottomNavItem("ai_assistant", "AI Assist", Icons.Default.AutoAwesome),
        BottomNavItem("nearby", "Nearby", Icons.Default.People),
        BottomNavItem("firstaid", "First Aid", Icons.Default.LocalHospital),
        BottomNavItem("shield", "Shield", Icons.Default.Security)
    )

    Scaffold(
        containerColor = Color(0xFF0A0A12),
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route
            if (currentRoute != "splash" && currentRoute != "register") {
                NavigationBar(
                    containerColor = Color(0xFF0D0D1A), 
                    tonalElevation = 0.dp
                ) {
                    val currentDestination = navBackStackEntry?.destination
                    items.forEach { item ->
                        val isAI = item.route == "ai_assistant"
                        val isSelected = currentDestination?.hierarchy?.any { it.route == item.route } == true
                        NavigationBarItem(
                            icon = { if (isAI) AIAssistantIcon(isSelected) else Icon(item.icon, null) },
                            label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                            selected = isSelected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            NavHost(navController = navController, startDestination = "splash", modifier = Modifier.padding(innerPadding)) {
                composable("splash") { SplashScreen(navController) }
                composable("register") { RegistrationScreen(viewModel, navController) }
                composable("home") { 
                    HomeScreen(
                        navController = navController, 
                        viewModel = viewModel, 
                        onNavigateToNearby = { navController.navigate("nearby") }, 
                        onNavigateToShield = { navController.navigate("shield") },
                        onTriggerDemo = { viewModel.triggerDemoAccident() }
                    ) 
                }
                composable("nearby") { NearbyScreen(viewModel, { navController.popBackStack() }) }
                composable("ai_assistant") { AIAssistantScreen(viewModel, navController) }
                composable("firstaid") { FirstAidScreen({ navController.popBackStack() }) }
                composable("shield") { EvidenceShieldScreen({ navController.popBackStack() }) }
                composable("profile") { ProfileScreen(navController, viewModel) }
                composable("hospitals") { NearbyHospitalScreen(viewModel, { navController.popBackStack() }) }
                composable("route_risk") { AiRouteRiskScreen({ navController.popBackStack() }) }
                composable("live_sos") { LiveSOSMonitoringScreen(viewModel, { navController.popBackStack() }) }
                composable("evidence_list") { EmergencyEvidenceScreen({ navController.popBackStack() }) }
            }

            // Realtime Emergency Popup
            incomingAlert?.let { alert ->
                Box(modifier = Modifier.fillMaxSize().padding(top = 20.dp), contentAlignment = Alignment.TopCenter) {
                    LiveEmergencyPopup(
                        emergency = alert,
                        onAccept = { viewModel.onICanHelp(alert) },
                        onDismiss = { viewModel.dismissAlert() }
                    )
                }
            }
        }
    }
}

@Composable
fun AIAssistantIcon(isSelected: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "ai_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f, 
        targetValue = if (isSelected) 1.2f else 1.05f, 
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse), 
        label = "scale"
    )
    Box(contentAlignment = Alignment.Center) {
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .scale(scale)
                    .background(Brush.radialGradient(listOf(Color(0xFF00F2FF), Color.Transparent)), CircleShape)
                    .graphicsLayer(alpha = 0.5f)
            )
        }
        Icon(
            Icons.Default.AutoAwesome, 
            null, 
            tint = if (isSelected) Color(0xFF00F2FF) else Color(0x66FFFFFF),
            modifier = Modifier.size(24.dp)
        )
    }
}
